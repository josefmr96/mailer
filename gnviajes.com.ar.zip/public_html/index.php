<?php
require_once("config/conexion.php");
require_once("models/Banner.php");
$banner = new Banner();

$listaBanners = $banner->obtener_Banner();
$promoEspecial = $banner->get_Banner_x_slut("PromoEspecial");
foreach($promoEspecial as $promo){

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-7XBG1KP2TB"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config','G-7XBG1KP2TB');
  </script>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="view/Components/styles.css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  <link  rel="icon"   href="logo.png" type="image/png" />
    <title>GNViaje | Inicio</title>
</head>

<body>
  <div class="back">
    <?php
    include('view/Components/header.php')
    ?>
<div class="container">
  <div class="row">
  <div style="display: grid;
    justify-content: space-around;"class="col-sm-12">
  <div style="    background-color: #f5f5f5;
    border-radius: 10px;
    border: 1px solid #eee;
    margin-bottom: 20px;
    /* height: 450px; */
    padding: 5px;
    width: 500px;
    display: flex;
    align-items: flex-end;" class="flex justify-center content-center relative">
      <img src="<?php echo $promo["url"]; ?>"  alt="design image" />
      <button class="absolute p-2 border-solid border-2 border-yellow-500 bg-amber-400 btn-color rounded font-bold cursor-pointer hover:bg-yellow-400 z-10">
                <a href="view/ViajesPromos?id=<?php echo $promo["slug"]; ?>" class="text-white">Ver Promoción</a>
                <!-- agregar referencia en el link para el viaje  -->
              </button>
      </div>
      </div>
  </div>
</div>
    <div class="contenedor">
      
      <section class="grilla">
        <?php foreach ($listaBanners as $banne) { ?>
          <div class="col-sm-4">
            <div class="card__container flex justify-center content-center relative">
              <img src="<?php echo $banne["url"]; ?>" class="h-full p-2 w-full rounded" alt="design image" />
              <button class="absolute p-2 border-solid border-2 border-yellow-500 bg-amber-400 btn-color rounded w-4/5 font-bold cursor-pointer hover:bg-yellow-400 z-10">
                <a href="view/ViajesPromos?id=<?php echo $banne["slug"]; ?>" class="text-white">Ver Promoción</a>
                <!-- agregar referencia en el link para el viaje  -->
              </button>
            </div>
          </div>
        <?php } ?>
      </section>
    </div>
    <!-- <div class="contenedor">
      <div class="col-sm-10">
        <h1 style="color: #fbbf24;
    font-weight: 900;
    border-bottom: 5px solid;
    font-size: 30px;
    border-color: #fbbf24;">TERMINOS Y CONDICIONES</h1>
      </div>
    </div>
    <div class="contenedor" style="margin-top: 15px;">


      <div class="col-sm-4">


        <div class="card__container flex justify-center content-center relative">
          <div>

          </div>


        </div>
      </div>
      <div class="col-sm-4">
        <div class="card__container flex justify-center content-center relative">
          <p></p>

        </div>
      </div>
    </div> -->
    <?php
    include('view/Components/footer.php')
    ?>
  </div>
</body>

</html>