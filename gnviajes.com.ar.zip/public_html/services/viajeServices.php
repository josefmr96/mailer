<?php
  require_once("../../config/conexion.php"); 
  require_once("../../models/Viaje.php");
 
  $viaje = new Fullday();
  
  function listar_provincias( $viaje){

    $viajes=$viaje->get_fullday_x_id($_GET["id"]);
   
  return   $viajes;
  }

  $aViaje = listar_provincias( $viaje); // guardamos los datos de la funcion en una variable para utilizarla luego
 


?>