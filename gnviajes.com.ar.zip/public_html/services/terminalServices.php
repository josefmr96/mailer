<?php
  require_once("../../config/conexion.php"); 
  require_once("../../models/Terminal.php");
 
  $terminal = new Terminal();
  
  function listar_terminales( $terminal){

    $terminales=$terminal->obtener_terminales();
   
  return   $terminales;
  }

  $aTerminal = listar_terminales($terminal); // guardamos los datos de la funcion en una variable para utilizarla luego
 


?>