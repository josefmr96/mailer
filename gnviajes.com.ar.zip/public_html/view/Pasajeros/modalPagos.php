<div id="modalPagos" class="modal fade bd-example-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="modal-close" data-dismiss="modal" aria-label="Close">
                    <i class="font-icon-close-2"></i>
                </button>
                <h4 class="modal-title" id="mdltitulo">Agregar Pago</h4>
            </div>
            <form method="post" id="usuario_formX">
                <div class="modal-body">
                    <input id="idpago" hidden name="idpago" >
                
                 
                    <div class="form-group">
                        <label class="form-label" for="cantidad">Total Pagado</label>
                        <input type="number" class="form-control" id="cantidad" name="cantidad" placeholder="">
                        
                    </div>     
                    <input id="idreservaXd" hidden name="idreservaXd" >
                    <fieldset class="form-group">
									<label class="form-label" for="metodo">Forma de Pago</label>
									<select class="select2"  form-control id="metodo" name="metodo">
										<option value=""  selected>Seleccionar</option>
										<option value="Transferencia">Transferencia</option>
										<option value="Mercado Pago">Mercado Pago</option>
										<option value="A Cuenta">A Cuenta</option>
										<option value="Efectivo/Micro">Efectivo/Micro</option>
										<option value="Otro">Otro</option>
                                    </select>
								</fieldset> 
                    
   
                     <div class="form-group">
                        <label class="form-label" for="numero_comprobante">Referencia del Comprobante</label>
                        <input type="text" class="form-control" id="numero_comprobante" name="numero_comprobante" placeholder="" required>
      
                    </div>   
                    
                      <div class="form-group">
                        <label class="form-label" for="observaciones">Observaciones</label>
                        <input type="text" class="form-control" id="observaciones" name="observaciones" placeholder="" required>
                  
                    
                    </div>   

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-rounded btn-default" data-dismiss="modal">Cerrar</button>
                    <button type="submit" name="action" id="#" value="add" class="btn btn-rounded btn-primary">Guardar</button>
                </div>
                </div>
                <div class="box-typical box-typical-padding">
                <table style="font-size:12px;" id="pago_data" class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th style="width: 10%;">Forma de Pago</th>
							<th class="text-center" style="width: 10%;">Total Pagado</th>
							<th class="text-center" style="width: 5%;">Referencia</th>
							<th class="text-center" style="width: 5%;">Observaciones</th>
							<!-- <th class="text-center" style="width: 5%;">Eliminar</th> -->
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
        </div>
            </form>
     
        </div>
    </div>
</div>