<?php
require_once("../../config/conexion.php"); 
require_once("../../models/Viaje.php"); 
$fullday= new Fullday();

$datos=$fullday->get_fullday_x_slug_y_titulo($_GET["id"],$_GET["titu"]);
foreach($datos as $descrip){ }





?>
<!DOCTYPE html>
<html lang="en">
  <head>
    
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link  rel="icon"   href="logo.png" type="image/png" />
    <title>GNViaje | Reservar</title>
    <link rel="stylesheet" href="../Components/styles.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
      crossorigin="anonymous"
    />
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="back">
      <?php 
        include('../Components/header.php')
      ?>
      <div class="contenedor direction bg-slate-50">
        <section class="sec__title__promo mb-5 bg-pink-500">
          <div>
            <h1 class="text-xl font-bold text-yellow-400">
              <?php echo $_GET["titu"] ?>
            </h1>
          </div>
        </section>
        <section class="container mb-5">
          <div class="row">
            <div class="card__container-promo">
              <div class="col-md-8 col">
                <img height="500px"
                width="600px"
                src="<?php echo $descrip["imagen"]; ?>"
                  alt="card image"
                />
              </div>
              <div
                class="col-md-4 ml-0  col card bg-yellow-100 text-orange-500 h-auto carda"
              >
                <div class="card-body">
                  <br>
                  <h1 style="text-transform: uppercase; font-size:20px" class="card-title font-bold text-pink-400">  <?php echo $descrip["titulo"]; ?></h1>
                  <br>
                  
                  <p class="card-text">
                  <?php echo $descrip["descripcion"] ?>
                  </p>
                  <div class="info-6">
                    <br>
                    <br>
                    <br>
                    <br>
                    <hr>
            <h2 class="text-pink-400 font-bold text-center">
              PUNTOS DE EMBARQUE
            </h2>
            <br>
            <ul>
          
              <li class="text-xs md:text-base mb-2">
                VARELA | Terminal de Varela AV Calchaquí 686 Princess |
              
              </li>
              <li class="text-xs md:text-base mb-2">
                AVELLANEDA | SHELL Av Hipolito Yrigoyen 3452 |
              </li>
              <li class="text-xs md:text-base mb-2">
                CAPITAL FEDERAL | Terminal Dellepiane /Av. Perito Moreno 3950 |
              </li>  
               <li class="text-xs md:text-base mb-2">
               SAN JUSTO | Terminal Av M. Buffano 3352 |
              </li>
              <li class="text-xs md:text-base mb-2">
                MORON | GNC Vergara y Gaona | 
              </li>
              <li class="text-xs md:text-base mb-2">
                PACHECO | Parador El Turista
                | 
              </li> 
               <li class="text-xs md:text-base mb-2">
               LANUS | YPF Av Hipolito Yrigoyen 3740
                | 
              </li>   
               <li class="text-xs md:text-base mb-2">
               LAVALLOL | YPF Rotonda Lavallol
                | 
              </li>
            </ul>
          </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="information__container mb-5">
          <div class="info-1 text-center">
            <h2 class="text-pink-400 font-bold text-center">
              SALIDAS PROGRAMADAS
            </h2>
            <br>
            <ul>
              <?php foreach($datos as $fechas){ 
               $newDate = date("d/m/Y", strtotime($fechas["fecha"])); ?>
              <li class="text-xs md:text-base">
                <b>Salida:</b>    <?php echo  $newDate; ?>
              </li>
              <br>
              <?php } ?>
            
            </ul>
          </div>
          <div class="info-2">
            <h2 class="text-pink-400 font-bold text-center">DETALLE GENERAL</h2> <br>
            <ul>
              <li class="text-xs md:text-base">
                <?php echo $fechas["descripcion"]; ?>
              </li>
            
            </ul>
          </div>
          <div class="info-3">
            <h2 class="text-pink-400 font-bold text-center">EXCURSIONES</h2>
            <br>
            <ul>
              <li class="text-xs md:text-base">
              <?php echo $fechas["excursiones"]; ?>
              </li>
              
            </ul>
          </div>
          <!-- <div class="info-4">
            <h2 class="text-pink-400 font-bold text-center">
              NUESTRA HOSTELERÍA
            </h2>
            <ul>
              <li class="font-bold text-sm">
                Cadena SUR = <br />
                Hoteles ANTÁRTIDA + TIVOLI + COSTA DEL LAGO.
              </li>
              <li class="text-xs md:text-base">
                <b>Web:</b>
                <a href="#" class="text-pink-400 hover:text-pink-500"
                  >enlace a página web hostel</a
                >
              </li>
              <li class="text-xs md:text-base">
                <b>Web:</b>
                <a href="#" class="text-pink-400 hover:text-pink-500"
                  >enlace a página web hotel</a
                >
              </li>
            </ul>
          </div> -->
          <!-- <div class="info-5">
            <h2 class="text-pink-400 font-bold text-center">
              ITINERARIO DE ACTIVIDADES
            </h2>
            <ul>
              <li class="text-xs md:text-base">
                <b>Día 1:</b> Salida a la mañana.
              </li>
              <li class="text-xs md:text-base">
                <b>Día 2:</b> Llegada a San Carlos de Bariloche / Check In Hoteles
                / tarde libre.
              </li>
              <li class="text-xs md:text-base">
                <b>Día 3:</b> Circuito Chico & Punto Panorámico + Cerro Campanario
                & Mirador Llao Llao + Cerro CATEDRAL a pura Nieve.
              </li>
              <li class="text-xs md:text-base">
                <b>Día 4:</b> Lagos & Bosques Patagónicos Ruta 40 + Visita a
                Fábrica de Chocolates Regionales.
              </li>
              <li class="text-xs md:text-base">
                <b>Día 5:</b> check out / tiempo libre para compras y centro de la
                Ciudad con Costanera del Lago Nahuel Huapy / Regreso 17 Hs / Noche
                en Viaje
              </li>
              <li class="text-xs md:text-base">
                <b>Día 6:</b> Llegada a la tarde / fin de los servicios.
              </li>
            </ul>
            <p class="font-bold text-xs mt-2">
              La empresa se reserva el derecho de alterar y / o modificar
              itinerarios y excursiones contratados ante cuestiones de
              diagramación y/o causas de fuerza mayor y / o caso fortuito que
              impidan el normal cumplimiento del mismo: corte de rutas x nevadas,
              huracanes, inundaciones, reprogramación de eventos y / o cualquier
              otro factor que pueda significar un riesgo o una falta de servicio
              para el pasajero.
            </p>
          </div> -->
      
        </section>
        <section>
          <h2
            class="p-2 rounded mb-5 text-center font-bold text-orange-500 bg-yellow-100"
          >
            ¡Hacé tu RESERVA!
          </h2>
          <div class="formulario__reserva bg-slate-50 mb-5">
            <?php foreach($datos as $via){ ?>

            
            <div class="fecha-1 p-2 bg-indigo-50 rounded border">
              <div>
                <p class="text-sm md:text-base mb-2">
                  Fecha de Salida: <?php echo date("d/m/Y", strtotime($via["fecha"])); ?>
                </p>
                <p class="text-sm md:text-base mb-2">
                  Disponibles:  <span class="text-pink-400"><b><?php echo $via["disponible"] ?></b></span>
                </p>
              </div>
              <!-- <form>
                <select class="p-2 text-center bg-indigo-100 rounded w-full mb-2">
                  <option value="selec">- Habitación -</option>
                  <option value="Doble">Doble Matrimonial</option>
                  <option value="DobleT">Doble Twin</option>
                  <option value="Triple">Triple</option>
                  <option value="Cuadruple">Cuadruple</option>
                </select>
              </form> -->
              <div class="mb-2">
                <h3>Precio x Pasajero</h3>
                <p class="text-pink-400"><b>$<?php echo $via["precio"] ?></b></p>
              </div>
              <?php if($via["disponible"] > 0){ ?>
              <div>
                <a  class="w-full p-2 rounded font-bold text-orange-500 bg-yellow-100 hover:bg-yellow-300" href="../PagarViaje?id=<?php echo $via["idfullday"]; ?>">RESERVAR
            </a>
              </div>
              <?php }else{ ?>
                <p class="text-pink-400"><b>AGOTADO</b></p>
              <?php }?>
            </div>
            <?php } ?>
          </div>
        </section>
      </div>
      <?php 
        include('../Components/footer.php')
      ?>
    </div>
  </body>
</html>
