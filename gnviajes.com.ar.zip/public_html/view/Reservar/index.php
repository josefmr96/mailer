<?php
  require_once("../../services/terminalServices.php");
  require_once("../../services/viajeServices.php");
  require_once("../../config/conexion.php"); 
  
 foreach ($aViaje as $viaje) {
	 # code...
 }



?>
<!DOCTYPE html>
<html>
    <?php require_once("../MainHead/head.php");?>
	<title>Reservas</title>
</head>
<body class="with-side-menu theme-side-caesium-dark-caribbean">

    <?php require_once("../MainHeader/header.php");?>

    <div class="mobile-menu-left-overlay"></div>
    
    <?php require_once("../MainNav/nav.php");?>

	<!-- Contenido -->
	<div class="page-content">
		<div class="container-fluid">
			<header class="section-header">
				<div class="tbl">
					<div class="tbl-row">
						<div class="tbl-cell">
							<h3> Reservas</h3>
							<ol class="breadcrumb breadcrumb-simple">
								<li><a href="#">Inicio</a></li>
								<li class="../Viajes"> Viajes</li>
								<li class="active"> Reservas</li>
							</ol>
						</div>
					</div>
				</div>
			</header>

			<div class="box-typical box-typical-padding">
				<?php if($viaje["disponible"] == 0) {?>

				<?php }else{ ?>
					<button type="button" id="btnnuevo" class="btn btn-inline btn-primary">Agregar nuevo Pasajero</button>
				
				<?php } ?>
				
				<br>
				<span class="label label-pill label-info"><?php echo 'Destino:'.$viaje["titulo"] ?></span>
				<br>
				<span class="label label-pill label-info"><?php echo 'Disponibles:'.$viaje["disponible"] ?></span>
				<table style="font-size:12px;" id="usuario_data" class="table table-bordered table-striped table-vcenter js-dataTable-full">
					<thead>
						<tr>
							<th style="width: 10%;">Cupon</th>
							<th class="text-center" style="width: 10%;">Pasajero</th>
							<th class="text-center" style="width: 5%;">Total</th>
							<th class="text-center" style="width: 5%;">Correo</th>
							<th class="text-center" style="width: 5%;">Telefono</th>
							<th class="text-center" style="width: 5%;">Viaje</th>
							<!-- <th class="text-center" style="width: 5%;">Pago</th>
							<th class="text-center" style="width: 5%;">Editar</th>
							<th class="text-center" style="width: 5%;">Eliminar</th> -->
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>

		</div>
	</div>
	<!-- Contenido -->



	<?php require_once("modalReservar.php");?>
	<?php require_once("modalPagos.php");?>
	<?php require_once("../MainJs/js.php");?>
	
	<script type="text/javascript" src="reservas.js"></script>

</body>
</html>
