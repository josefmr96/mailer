<header class="mt-5 mb-5">
  <div class="logo">
    <a href="#">
      <img src="logo.png" alt="no logo" />
    </a>
  </div>
  <nav class="nav-bar">
    <div class="nav-menu d-md-block">
      <ul class="main-menu d-md-block">
        <li>
          <a class="text-xs md:text-base" href="https://gnviajes.com.ar">Inicio</a>
        </li>
        <li>
          <a class="text-xs md:text-base" href="https://gnviajes.com.ar">Reservas</a>
        </li>
        <li>
          <a class="text-xs md:text-base" href="https://gnviajes.com.ar">Promociones</a>
        </li>
        <li style="margin-right: 0">
          <a class="text-xs md:text-base" href="https://gnviajes.com.ar">Contacto</a>
        </li>
      </ul>
    </div>
  </nav>
</header>