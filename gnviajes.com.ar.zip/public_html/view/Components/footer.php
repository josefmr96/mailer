<footer class="bg-pink-600" style="    color: #fbbf24;">
  <div class="container">
    <div class="space">
      <div class="row justify-content-center">
        <div class="col-12 col-md-4 mt-3">
          <h2 class="font-bold text-center mb-2">GNViajes</h2>
          <hr class="text-white hor" />
          <nav class="texto">
            <ul>
              <li>
                <a href="#Inicio">Inicio</a>
              </li>
              <li>
                <a href="#Reservas">Reservas</a>
              </li>
              <li>
                <a href="#Promociones">Promociones</a>
              </li>
            </ul>
          </nav>
        </div>
        <div class="col-12 col-md-4 mt-3">
          <h2 class="font-bold text-center mb-2">Contacto</h2>
          <hr class="text-white hor" />
          <nav class="texto">
            <ul>
              <li>
                <a href="#Inicio">gnviajestravelhotel@gmail.com</a>
              </li>
              <li>
                <!-- <a href="#Reservas">Teléfono: 1122334455</a> -->
              </li>
              <li>
                <!-- <a href="#Promociones">Whatsapp: 1122334455</a> -->
              </li>
            </ul>
          </nav>
        </div>
        <div class="col-12 col-md-4 mt-3">
          <h2 class="font-bold text-center mb-2">Reglas</h2>
          <hr class="text-white hor" />
          <nav class="texto">
            <ul>
              <li>
                <a href="#Inicio">Términos y Condiciones</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</footer>