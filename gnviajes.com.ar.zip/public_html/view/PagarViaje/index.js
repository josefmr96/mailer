const nuevoFormulario = document.querySelector('#form-info')
const precio = document.getElementById('precioT').value
const total = document.getElementById('total')
const oferta = document.getElementById('ofertaS')
const boton = document.getElementById('btnPOST')
const pass3 = document.querySelector('.pass3')
const pass4 = document.querySelector('.pass4')
const pass5 = document.querySelector('.pass5')

const handleChange = (e) => {
  const selector = document.querySelector('#pasajeros')
  const cantidad = document.querySelector('.carda')
  cantidad.classList.add('notclick')
  //selector.setAttribute('disabled', 'disabled') CUANDO SE HACEN PETICIONES POST NO SE PUEDE DISABLE TIENE QUE SER READONLY -- Oki, no sabía :D

  if (selector.value === '2') {

    total.textContent = `$ ${precio * 2}`
    boton.disabled = false;
  } 
  
  
    if (selector.value === '2x1') {
      console.log(boton);
      boton.disabled = false;
    total.textContent = `$ ${precio * 1}`
  }     
   if (selector.value === '4x1') {
    boton.disabled = false;
    total.textContent = `$ ${precio * 2}`
  }  
  if (selector.value === '3') {
    pass3.classList.remove('hidden')
    total.textContent = `$ ${precio * 3}`
    boton.disabled = false;
  }

  if (selector.value === '4') {
    pass3.classList.remove('hidden')
    pass4.classList.remove('hidden')
    boton.disabled = false;
      total.textContent = `$ ${precio * 4}`
  
   
  }

  if (selector.value === '5') {
    pass3.classList.remove('hidden')
    pass4.classList.remove('hidden')
    pass5.classList.remove('hidden')
    total.textContent = `$ ${precio * 5}`
    boton.disabled = false;
  }
}
