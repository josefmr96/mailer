<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body style="background: linear-gradient(to right, #499ee8, #e11ca3);
    font-family: sans-serif;">
    <div style="    text-align: center;
    width: 600px;
   
    font-weight: 900;
    background-color:#fef9c3;">
    <h1 style="    text-transform: uppercase;
    font-size: 20px;
    color: #f35db5;
    font-size: 25px;">Reserva Creada con Exito</h1>
    <div style="color:#f85b00;
        font-size: 15px;">
        <h5></h5>
    <p>Para hacer efectiva tu reserva debes pagar una seña antes de 48hs de lo contrario tu reserva sera dada de baja</p>
    <p>Una vez realizada la seña puedes mandar el comprobante por correo <span style="font-weight:bold">gnviajestravelhotel@gmail.com</span> o el WhatsApp de la empresa <span style="font-weight:bold"></span></p>
    <p>Puedes consultar tu reserva en el siguiente enlace</p>
    <button type="submit" name="btnPOST" id="btnPOST" class="w-full p-3 bg-pink-100 hover:bg-pink-200 text-pink-400 font-bold rounded">
          Datos de la Reserva
        </button>
    </div>
    </div>
    <div style="--tw-bg-opacity: 1;
     text-align: center;
      width: 600px;
    background-color: rgb(234 250 252 / var(--tw-bg-opacity));">
        <h1>Metodos de Pago</h1>
        <div>
            Juan

        </div>
        <div>
            Pedro
            </div>
            <div>
            Alo
            </div>
            <div>
            Culñ
            </div>
    </div>
    <div style="--tw-bg-opacity: 1;
     text-align: center;
      width: 600px;
    background-color: rgb(234 250 252 / var(--tw-bg-opacity));">
        <h1>Datos de los pasajeros</h1>
        <div>
            Juan

        </div>
        <div>
            Pedro
            </div>
            <div>
            Alo
            </div>
            <div>
            Culñ
            </div>
    </div>
</body>
</html>