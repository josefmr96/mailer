<!DOCTYPE html>
<html
    lang="en"
    xmlns="http://www.w3.org/1999/xhtml"
    xmlns:o="urn:schemas-microsoft-com:office:office"
>
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="x-apple-disable-message-reformatting" />
  <title>Email</title>
  <!--[if mso]>
    <noscript>
      <xml>
        <o:OfficeDocumentSettings>
          <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
      </xml>
    </noscript>
  <![endif]-->
</head>
<body style="margin: 0; padding: 0;">
  <style>
    /* Font Family */
    @import url("https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;700;900&family=Roboto:wght@400;500&display=swap");
    /* variables */
    :root {
      --color-main: #f1298f;
      --color-sec: #3c2f6b;
      --color-tec: #355cf4;
      --color-gray: #eee;
      --color-black: #303030;
      --color-white: #f5f5f5;
    }

    * {
      font-family: "Inter", sans-serif;
    }
  </style>
  <?php $cuerpoMail= '<table
    role="presentation"
    style="
      width: 100%;
      border-collapse: collapse;
      border: 0;
      border-spacing: 0;
      background: var(--color-gray);
    ">
      <tr>
        <td align="center" style="padding: 0">
          <table 
            role="presentation"
            style="
                width: 602px;
                border-collapse: collapse;
                border-spacing: 0;
                text-align: center;
            "
          >
            <tr>
              <td style="
                border-top-right-radius: 48px;
                border-top-left-radius: 48px;
                padding: 20px 0 32px 0;
                margin: 0;
                background-color: var(--color-white);
                "
              >
                  <img src="logo.png" alt="logo">
              </td>
            </tr>
            <tr>
              <td
                  align="center"
                  style="
                      padding: 0;
                      background: var(--color-white);
                  "
              >
                  <img
                      src="viajes.jpg"
                      alt="logo image"
                      width="600px"
                      style="height: auto; display: block"
                  />
              </td>
            </tr>
            <tr>
              <td align="center" style="padding: 36px 30px 42px 30px; background-color: var(--color-gray)">
                <table 
                  role="presentation"
                  style="
                    width: 100%;
                    border-collapse: collapse;
                    border: 0;
                    border-spacing: 0;
                  "
                >
                  <h2
                    align="center"
                    style="
                      color: var(--color-sec);
                      font-size: 28px;
                      font-weight: 700;
                      line-height: 41.44px;
                      margin: 0 0 20px 0;
                    "
                  >
                    Datos Personales
                  </h2>
                  <tr>
                    <td
                      align="center"
                      style="
                          padding: 0 15px 0 0;
                          color: var(--color-sec);
                          font-size: 14px;
                      "
                    >
                      <h3 
                        align="center"
                        style="
                          color: var(--color-main);
                          margin: 0 0 12px 0;
                          font-size: 20px;
                          font-weight: 600;
                          line-height: 24.8px;
                        "
                      >
                        Pasajero 1
                      </h3>
                      <p style="font-weight: 700; color: var(--color-black)">Nombre: <span style="font-weight: 400">Nombre</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Apellido: <span style="font-weight: 400">Apellido</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Celular: <span style="font-weight: 400">Celular</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">DNI/PASAPORTE: <span style="font-weight: 400">DNI/PASAPORTE</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Edad: <span style="font-weight: 400">Edad</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Fecha de nacimiento: <span style="font-weight: 400">Fecha de nacimiento</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Nacionalidad: <span style="font-weight: 400">Nacionalidad</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Régimen de comida: <span style="font-weight: 400">Régimen de comida</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">PUERTA DE EMBARQUE: <span style="font-weight: 400">PUERTA DE EMBARQUE</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Datos Extra: <span style="font-weight: 400">Datos Extra</span></p>
                    </td>
                    <td
                      align="center"
                      style="
                      padding: 0 0 0 15px;
                        color: var(--color-sec);
                        font-size: 14px;
                      "
                    >
                      <h3
                        align="center"
                        style="
                          color: var(--color-main);
                          margin: 0 0 12px 0;
                          font-size: 20px;
                          font-weight: 600;
                          line-height: 24.8px;
                        "
                      >
                        Pasajero 2
                      </h3>
                      <p style="font-weight: 700; color: var(--color-black)">Nombre: <span style="font-weight: 400">Nombre</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Apellido: <span style="font-weight: 400">Apellido</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Celular: <span style="font-weight: 400">Celular</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">DNI/PASAPORTE: <span style="font-weight: 400">DNI/PASAPORTE</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Edad: <span style="font-weight: 400">Edad</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Fecha de nacimiento: <span style="font-weight: 400">Fecha de nacimiento</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Nacionalidad: <span style="font-weight: 400">Nacionalidad</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Régimen de comida: <span style="font-weight: 400">Régimen de comida</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">PUERTA DE EMBARQUE: <span style="font-weight: 400">PUERTA DE EMBARQUE</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Datos Extra: <span style="font-weight: 400">Datos Extra</span></p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td 
                align="center"
                style="
                    padding: 0 0 30px 0;
                    background: var(--color-white);
                "
              >
                <table 
                  role="presentation"
                  style="
                      width: 602px;
                      border-collapse: collapse;
                      border-spacing: 0;
                      margin-left: 10px;
                    "
                >
                  <tr>
                    <td
                      align="center"
                      style="
                          padding: 0 15px 0 0;
                          color: var(--color-sec);
                      "
                    >
                      <h2
                        align="center"
                        style="
                          color: var(--color-sec);
                          font-size: 28px;
                          font-weight: 700;
                          line-height: 41.44px;
                          margin: 20px 0 20px 0;
                        "
                        >
                          Detalles de la reserva
                      </h2>
                    </td>
                  </tr>
                  <tr>
                    <td
                      align="left"
                      style="
                          padding: 0 15px 15px 0;
                          color: var(--color-sec);
                      "
                    >
                      <p style="font-weight: 700; color: var(--color-black)">Destino: <span style="font-weight: 400">Destino</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Habitación: <span style="font-weight: 400">Habitación</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Fecha de salida: <span style="font-weight: 400">Fecha de salida</span></p>
                      <p style="font-weight: 700; color: var(--color-black)">Valor del paquete por persona: <span style="font-weight: 400; color: var(--color-main)">Valor del paquete por persona</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td
                      align="center"
                      style="
                          padding: 0 15px 0 0;
                          color: var(--color-sec);
                      "
                    >
                      <h2
                        align="center"
                        style="
                          color: var(--color-sec);
                          font-size: 28px;
                          font-weight: 700;
                          line-height: 41.44px;
                          margin: 0 0 20px 0;
                        "
                        >
                          Valor total a pagar
                      </h2>
                      <h2
                        align="center"
                        style="
                          color: var(--color-main);
                          font-size: 28px;
                          font-weight: 900;
                          line-height: 41.44px;
                          margin: 0 0 20px 0;
                        "
                        >
                          $$$
                      </h2>
                    </td>
                  </tr>
                  <tr>
                    <td
                      align="center"
                      style="
                        margin-top: 20px;
                        padding: 20px 15px 0 0;
                        color: var(--color-sec);
                      "
                    >
                      <h2
                        align="center"
                        style="
                          color: var(--color-sec);
                          font-size: 28px;
                          font-weight: 700;
                          line-height: 41.44px;
                          margin: 0 0 20px 0;
                        "
                        >
                          Datos de pago
                      </h2>
                      <p
                        align="left"
                        style="
                          color: var(--color-black);
                          font-size: 18px;
                          font-weight: 600;
                          line-height: 41.44px;
                          margin: 0 0 20px 0;
                        "
                        >
                          CBU:
                          <span style="font-weight: 900; font-size: 20px">001144557788449988</span>
                      </p>
                      <p
                        align="left"
                        style="
                          color: var(--color-black);
                          font-size: 18px;
                          font-weight: 600;
                          line-height: 41.44px;
                          margin: 0 0 20px 0;
                        "
                        >
                          Alias:
                          <span style="font-weight: 900; font-size: 20px">perrito.feliz</span>
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td 
                style="
                  padding: 40px;
                  border-top: 15px solid var(--color-main);
                  background-color: var(--color-white);
                  border-bottom-left-radius: 48px;
                  border-bottom-right-radius: 48px;
                "
              >
                <table
                  role="presentation"
                  style="
                    width: 100%;
                    border-collapse: collapse;
                    border: 0;
                    border-spacing: 0;
                    font-size: 14px;
                  "
                >
                  <tr>
                    <td>
                    <table
                      role="presentation"
                      style="
                          width: 100%;
                          border-collapse: collapse;
                          border: 0;
                          border-spacing: 0;
                      "
                    > 
                      <tr>
                        <td style="padding-bottom: 20px">
                          <img src="logo.png"/>
                        </td>
                      </tr>

                      <tr>
                        <td>
                          <a
                            style="
                                color: var(--color-black);
                                text-decoration: none;
                                font-weight: 500;
                            "
                            href="#"
                            >
                              Términos y
                              condiciones
                            </a>
                        </td>
                      </tr>
                    </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>'; ?>
<?php echo $cuerpoMail; ?>    
</body>
</html>