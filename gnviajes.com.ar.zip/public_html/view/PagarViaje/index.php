<?php
require_once("../../config/conexion.php");
require_once("../../models/Viaje.php");
require_once("../../models/Reserva.php");
require_once("../../models/Pasajero.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require "../../PHPMailer/src/PHPMailer.php";
require "../../PHPMailer/src/SMTP.php";
require "../../PHPMailer/src/Exception.php";

$mail = new PHPMailer(true);

$fullday = new Fullday();
$reserva =  new Reserva();
$pasajero =  new Pasajero();
$datos = $fullday->get_fullday_x_id($_GET["id"]);

foreach ($datos as $viaje) {
}
$idfullday = $_GET["id"];
if (isset($_POST["btnPOST"])) {

  $idfullday;
  $cupon = time();
  $cantidad = $_POST["pasajeros"];
  $correo = $_POST["email"];
  $celu1 = $_POST["celular"];
  $total = intval($_POST["precioT"]) * intval($_POST["pasajeros"]);
  $precio = $_POST["precioT"];
  $habitacion = $_POST["habitacion"];
  //CREACION DE LA RESERVA
  $reserva->insert_reserva($cupon, $precio, $total, $cantidad, $idfullday, $correo, $celu1,$habitacion);
  //

  $no1 = $_POST["nombre"];
  $ape1 = $_POST["apellido"];

  $edad1 = $_POST["edad"];
  $dni1 = $_POST["dni"];
  $nac1 = $_POST["nacionalidad"];
  $fech1 = $_POST["fecha-nac"];
  $comid1 = $_POST["comida"];
  $terminal1 = $_POST["embarque"];
  $extra1 = $_POST["extra"];

  $no2 = $_POST["nombre2"];
  $ape2 = $_POST["apellido2"];
  $edad2 = $_POST["edad2"];
  $dni2 = $_POST["dni2"];
  $nac2 = $_POST["nacionalidad2"];
  $fech2 = $_POST["fecha-nac2"];
  $comid2 = $_POST["comida2"];
  $terminal2 = $_POST["embarque2"];
  $extra2 = $_POST["extra2"];

  $no3 = $_POST["nombre3"];
  $ape3 = $_POST["apellido3"];
  $edad3 = $_POST["edad3"];
  $dni3 = $_POST["dni3"];
  $nac3 = $_POST["nacionalidad3"];
  $fech3 = $_POST["fecha-nac3"];
  $comid3 = $_POST["comida3"];
  $terminal3 = $_POST["embarque3"];
  $extra3 = $_POST["extra3"];

  $no5 = $_POST["nombre5"];
  $ape5 = $_POST["apellido5"];
  $edad5 = $_POST["edad5"];
  $dni5 = $_POST["dni5"];
  $nac5 = $_POST["nacionalidad5"];
  $fech5 = $_POST["fecha-nac5"];
  $comid5 = $_POST["comida5"];
  $terminal5 = $_POST["embarque5"];
  $extra5 = $_POST["extra5"];

  $no4 = $_POST["nombre4"];
  $ape4 = $_POST["apellido4"];
  $edad4 = $_POST["edad4"];
  $dni4 = $_POST["dni4"];
  $nac4 = $_POST["nacionalidad4"];
  $fech4 = $_POST["fecha-nac4"];
  $comid4 = $_POST["comida4"];
  $terminal4 = $_POST["embarque4"];
  $extra4 = $_POST["extra4"];
  $pasajero->insert_Pasajero($no1, $comid1, $ape1, $edad1, $fech1, $dni1, $nac1, $extra1, $terminal1, $cupon,$_GET["id"]);
  if ($no2 != null || $no2 != '') {
    $pasajero->insert_Pasajero($no2, $comid2, $ape2, $edad2, $fech2, $dni2, $nac2, $extra2, $terminal2, $cupon,$_GET["id"]);
  }
  if ($no3 != null || $no3 != '') {
    $pasajero->insert_Pasajero($no3, $comid3, $ape3, $edad3, $fech3, $dni3, $nac3, $extra3, $terminal3, $cupon,$_GET["id"]);
  }
  if ($no4 != null || $no4 != '') {
    $pasajero->insert_Pasajero($no4, $comid4, $ape4, $edad4, $fech4, $dni4, $nac4, $extra4, $terminal4, $cupon,$_GET["id"]);
  }
  if ($no5 != null || $no4 != '') {
    $pasajero->insert_Pasajero($no5, $comid5, $ape5, $edad5, $fech5, $dni5, $nac5, $extra5, $terminal5, $cupon,$_GET["id"]);
  }
  try {
    //Server settings
    //$mail->SMTPDebug = SMTP::;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.hostinger.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'reservas@gnviajes.com.ar';                     //SMTP username
    $mail->Password   = 'Valla123.';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->SMTPOptions = array(
      'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
      )
    );
    //Recipients
    $mail->setFrom('reservas@gnviajes.com.ar', 'Reservas GnViajes(No responder)');
    $mail->addAddress($correo, ' ');     //Add a recipient
    // $mail->addCC('gnviajestravelhotel@gmail.com');
    $mail->addCC('gnviajestravelhotel@gmail.com');


    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Reserva realizada con exito';
    $message  = "<html><body>";

          $message .= "<table width='100%' bgcolor='#e0e0e0' cellpadding='0' cellspacing='0' border='0'>";

          $message .= "<tr><td>";

          $message .= "<table align='center' width='100%' border='0' cellpadding='0' cellspacing='0' style='max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;'>";

          $message .= "<thead>
            <tr height='80'>
            <th colspan='4' style='background-color:#ca6617; border-bottom:solid 1px #bdbdbd; font-family:Verdana, Geneva, sans-serif; color:black; font-size:34px;' >Reserva Realizada con Exito! #" . $cupon . ".</th>
            </tr>
                      </thead>";

          $message .= "<tbody>
                      <tr align='center' height='50' style='font-family:Verdana, Geneva, sans-serif;'>
                <p style='color:black;'>Para hacer efectiva tu reserva debes pagar una seña del 30% antes de 48hs de lo contrario tu reserva sera dada de baja

                Una vez realizada la seña puedes mandar el comprobante por correo gnviajestravelhotel@gmail.com o el WhatsApp de la empresa
                
               
                </tr>
                
                <tr>
                <td colspan='4' style='padding:15px;'>
                <p style='font-size:20px;'> " . $viaje["titulo"] . " <br>  " . $viaje["descripcion"] . " <br>  " . $newDate = date("d/m/Y", strtotime($viaje["fecha"])) . "</p>
                <p style='font-size:20px;'> Total a Pagar:$" . $total . " <br>
                Habitacion:$" . $habitacion . " <br>
                Numero de pasajeros:" . $cantidad . "
                Correo Contacto:" . $correo . " <br>
                Telefono Contacto:" . $celu1 . " <br></p>
                <hr />
                <p style='font-size:25px;'>Metodos de Pago</p>
                <p>BANCO MACRO
                CBU:2850540440095494150638</p>
                 <p>BANCO Supervielle
                CBU:0270002120039624110048</p>
                <p>Open Bank
                CBU:1580001101030007031229</p>
                <br>
                <hr>
                <p>Guillermo Nicolas Vallarino 
                 <br>
             
                CUIT/CUIL: 20326591093 
                </p>
                
                </td>
              
                </tr>

                <tr>
                <td colspan='4' style='padding:15px;'>
                <hr />
                $no1
                $ape1
                $edad1
                $dni1
                $nac1
                $fech1
                $comid1
                $terminal1
                $extra1
                $celu1
                <hr>
                $no2
                $ape2
                $edad2
                $dni2
                $nac2
                $fech2
                $comid2
                $terminal2
                $extra2
                <hr>
                $no3
                $ape3
                $edad3
                $dni3
                $nac3
                $fech3
                $comid3
                $terminal3
                $extra3
                <hr>
                $no5
                $ape5
                $edad5
                $dni5
                $nac5
                $fech5
                $comid5
                $terminal5
                $extra5
                <hr>
                $no4
                $ape4
                $edad4
                $dni4
                $nac4
                $fech4
                $comid4
                $terminal4
                $extra4
                <hr>
                <br>
                <br>
                <br>
                <br>
                
                <p style='font-size:9px;'>
                Legales Servicios Terrestres
              Clausula COVID SERVICIOS EN BUS.

              LA EMPRESA BRINDA A TODOS SUS PASAJEROS UN SEGURO COVID SIN CARGO.
              En caso de que el/los pasajero/s no pueda/n realizar el viaje por ser COVID positivo, debidamente acreditado en la Empresa con una anterioridad NO MENOR a las 72 hs previas a la salida, se aplicará lo siguiente:

              Solicitar nota de crédito dineraria para ser utilizada a futuro sobre el 100 % de lo abonado. Deberá respetar el mismo destino seleccionado, ya que los pasajes quedan nominados. Deberá abonar diferencia tarifaria de servicios en el caso de existir.
              Solicitar el reintegro de lo abonado con previa deducción de la franquicia (50 % del costo total del tour).
              En caso de que el / los pasajeros cancelen su viaje por enfermedad y no se presente al embarque sin avisar (NO SHOW): perderá el valor abonado.
              EN TODOS LOS CASOS, LOS PASAJEROS COVID POSITIVO, QUE ACREDITEN SU SITUACION  POR CORREO ELECTRÓNICO A gnviajestravelhotel@gmail.com CON UNA ANTICIPACION MENOR A LAS 72 HS PREVIAS A LA SALIDA, TENDRÁN UNA RETENCIÓN DEL 80 % DEL VALOR DEL VIAJE. EL 20 % RESTANTE SERA RECONOCIDO AL PASAJERO EN UNA NOTA DE CREDITO DINERARIA BAJO LAS CONDICIONES DETALLADAS ANTERIORMENTE.
              EN CASOS DE NO SHOW SIN PREVIO AVISO, LA RETENCION SERA DEL 100 % DEL VALOR DEL VIAJE.
              PARA EVITAR DICHA RETENCION Y HACER USO DE LAS EXCELENTES OPCIONES QUE BRINDA LA EMPRESA, RECOMENDAMOS AL PASAJERO TESTEARSE ENTRE LOS DIAS 04 Y 05 ANTERIORES A LA FECHA DE VIAJE.

              DOCUMENTACION para VIAJAR
              LA DOCUMENTACIÓN (DNI/Pasaportes/Visas/Permisos de Menores/ Permisos Sanitarios) ES EXCLUSIVA RESPONSABILIDAD DE LOS PASAJEROS. La misma debe estar en regla y en excelente estado, cumpliendo con actuales y futuras medidas emanadas de gobiernos nacionales, provinciales, municipales en este contexto de actual pandemia, para poder transitar dentro de nuestras fronteras o salir del país. En caso de no tenerla correctamente, los gastos que existieran correrán por cuenta de los pasajeros, quedando la empresa exenta de responsabilidad alguna. En ningún caso se procederá a reintegro, reprogramación o nota de crédito a favor del pasajero si incumple con alguno de los requisitos anteriormente enunciados.
              PARA INGRESAR A BRASIL: https://www.argentina.gob.ar/aplicaciones/fronteras/recomendaciones/brasil
              PARA INGRESAR A URUGUAY: https://www.argentina.gob.ar/aplicaciones/fronteras/recomendaciones/uruguay
              REFERENTE AL PAGO
              • NO se efectuará ninguna devolución por servicios a los que el pasajero renunciare voluntariamente y/o no tuviese la documentación personal en condiciones para viajar al momento de embarque.
              • A los pasajeros o empresas contratantes que cumplan con las condiciones de anulación de la contratación del servicio antes de los treinta (30) días de la fecha de salida pactada se les retendrá la seña del tour; si las cumplimentan entre los 29 y 15 días antes de la fecha de salida pactada se les retendrá el 70 % del valor total del tour y con menor anticipación que el último período mencionado no se reintegrará suma alguna. Ver excepciones SEGUROS OFRECIDOS.
              • En caso de ser las señas | montos estipulados y abonados en concepto de RESERVA DEL SERVICIO mayores a cualquier porcentaje de retención mencionado en el párrafo anterior, se retendrá el valor de la seña.
              • Las señas | montos estipulados y abonados en concepto de RESERVA DEL SERVICIO, cuyo valor figura en publicaciones web de la Empresa, no se reintegrarán bajo ningún concepto.
              • Los pagos con tarjeta de crédito / débito realizados a través de Mercadopago se confirman con el envío completo de la PLANILLA DE CONFIRMACIÓ DE PAGO ONLINE. En caso de no recibirla, aún cuando Mercadopago confirme la operación, queda a criterio de la Empresa brindar el servicio o dar de baja la reserva de viaje.
              • Una vez vencida la fecha de saldo estipulada en la PLANILLA DE RESERVA DE CUPO del | los PASAJEROS (15 días antes del embarque del viaje para circuitos terrestres), la empresa podrá proceder a la baja de los cupos impagos total y/o parcialmente sin previo aviso, independientemente de la seña que haya abonado el | los pasajeros. El pasajero podrá solicitar el Restablecimiento de su Reserva, en caso de existir disponibilidad de cupos, previo pago de un gasto administrativo de $ 2500 por pasajero.
              MEDIOS DE PAGO (exclusivos y excluyentes)
              - Transferencias bancarias a cuentas referidas por la Empresa en la planilla de pre reservas que llega al correo del pasajero.
              - Tarjetas de crédito / débito ON LINE a través de Mercadopago, utilizando sólo el link habilitado para tal fin en Planilla de Reservas de cada pasajero.
              - Tarjetas de crédito / débito en POSNET Oficinas Comerciales de la Empresa.
              - Efectivo en oficinas Comerciales de la Empresa.
              La Empresa desconocerá cualquier pago total o parcial realizado por otra vía

              CANON Y HONORARIOS
              Canon turístico y Honorario la de Guias debe ser abonado SIN EXCEPCIÓN, según corresponda cada uno, para cumplir con el contrato de viaje y servicio contratado.
              El costo de los mismos, puede variar según aumento del costo de vida que repercute en insumos. El pasajero al abonar el tour congela el precio del viaje, no así el de canon y honorarios que puede variar.
              COMUNICACIÓN
              • Toda comunicación hacia pasajero será efectuada a través de mails. Se hará a la casilla de correo indicada por el pasajero al hacer su reserva. El pasajero al reservar acepta dicho medio de comunicación como exclusivo y excluyente.
              • Toda comunicación emanada por parte del pasajero hacia la Empresa deberá ser efectuada a través de mails. Para ello deberá hacerse a la siguiente casilla de correo electrónico = contacto@kilometrounoviajes.com.ar . El pasajero al reservar acepta dicho medio de comunicación como exclusivo y excluyente.

              AUSENCIA DEL PASAJERO
              Al momento de embarcar (sea en origen, destino, regreso, excursiones…) se esperará al pasajero faltante hasta 15 minutos. Una vez transcurrido este tiempo se asumirá que el pasajero ha renunciado voluntariamente al servicio.

              MENORES
              • Pasajeros menores de 3 años (inclusive) que viajen bajo modalidad INFOA sin cargo: no dispondrán de butaca, cama ni pensión debiendo compartir esto con los mayores a su cargo. Deben estar acompañados por al menos 2 (dos) mayores de 3 años pagantes para obtener dicho beneficio.
              • En el caso de viajar con menores de edad deberá estar CLARAMENTE acreditado parentesco hijo / padre - madre a través de datos de progenitores en DNI nuevo o (en el caso de no figurar) a través de PARTIDA DE NACIMIENTO. Se puede chequear documentacion para viajar en el siguiente link: https://www.argentina.gob.ar/viajar-con-menores-de-edad-en-micros-de-larga-distancia

              RESERVAS ON LINE
              Las reservas en estas modalidades, estarán disponibles para ser señadas hasta las 18hs del día posterior a la fecha de reserva o hasta agotar agotar cupo de 59 pasajeros, lo que ocurra primero. En el caso de agotarse el stock primero queda sin efecto la misma sin derecho a reclamo alguno por parte del posible pasajero.

              PASAJEROS anotados bajo Modalidad HABITACION A COMPARTIR
              • En el caso de que el pasajero haya contratado una habitación a compartir con otros pasajeros: LA EMPRESA se reserva el derecho de asignarle alojamiento en cualquiera de los hoteles ofertados en la promo contratada, dependiendo de cantidad de pasajeros del mismo sexo anotados bajo la misma modalidad.
              • En el caso de que el pasajero haya contratado una habitación a compartir con otros pasajeros: La empresa se reserva el derecho de modificar la fecha de salida si no se han anotado otros pasajeros del mismo sexo para compartir habitación, independientemente del pago total o parcial recibido. Se debe informar al pasajero con un mínimo de 96 horas anteriores a la salida. El pasajero en dicho caso puede optar por el reintegro del dinero abonado en caso que la nueva fecha propuesta no sea de su agrado.

              CAMBIOS DE NÚMERO DE PASAJEROS CONTRATADOS
              En el caso de que el pasajero haya contratado una habitación| apart | cabaña exclusiva para su grupo (nominados bajo el mismo número de reserva grupal) y en cualquier momento, antes de viajar, ese número de pasajeros sufra bajas: LA EMPRESA se reserva el derecho de asignarles un nuevo alojamiento acorde al número de pasajeros vigente sin ningún tipo de reintegro.

              HOTELERÍA
              La EMPRESA se reserva el derecho de cambiar el hotel seleccionado por el pasajero al momento de la reserva, por otro de los ofertados (se ofrecen al mismo precio) o de similares características , si la distribución de habitaciones del viaje así lo requiere. El pasajero será informado vía VOUCHER grupal.
              EQUIPAJE
              Se permite en viajes terrestres 1 valija / bolso de hasta 23 kg y un bolso de mano de hasta 8 kg por pasajero.
              • El organizador se desvincula de los daños y / o pérdida, deterioro o sustracción del equipaje y / o elementos de uso personal que pudieran sufrir los PASAJEROS, ya sea por propios o por terceros. Al respecto hay seguros a muy bajo costo que cubren los eventuales señalados. Los mismos deben ser contratados por los pasajeros por separado.
              COBERTURA MÉDICA
              • En caso de que el/los pasajero/s no pueda realizar el viaje por causas médicas, debidamente justificadas, se le otorgará una Nota de CREDITO dineraria para ser utilizada a futuro. En NINGUN caso se aplicará reintegro.
              • Viajes a destinos NACIONALES: EL pasajero podrá contratarlo al reservar su viaje.
              El seguro MEDICO de Viaje es la garantía para cubrirte ante posibles emergencias médicas que tengas durante tu viaje.
              El organizador se desvincula de los daños y / o accidentes que pudieran sufrir, ya sea por propios o por terceros, el o los pasajeros/as que NO cuenten con dicho seguro (contratado a la empresa o a terceros).
              • COBERTURA MÉDICA Viajes a destinos de PAISES LIMITROFES: Los señores pasajeros viajan bajo su exclusiva responsabilidad, por lo que el organizador se desvincula de los daños y / o accidentes que pudieran sufrir, ya sea por propios o por terceros. Al respecto hay seguros a muy bajo costo que cubren los eventuales señalados. Los mismos deben ser contratados por los pasajeros por separado.
              CAMBIOS DE FECHA DE VIAJE y/o de PASAJERO
              • Cambio de fecha de viaje = no disponible / no aplica.
              • Cambio de destino = no disponible / no aplica.
              • Cambio de pasajero = no disponible / no aplica.

              • Seguro de CANCELACIÓN Flexi Viaje x Covid: El seguro FLEXI VIAJE sin cargo te garantiza el Reintegro o Reprogramación de tu viaje en caso de que el mismo deba ser cancelado por causas de fuerza mayor general: pandemias, desastres naturales, etc.

              REALIZACIÓN
              Base a un mínimo de 30 pasajeros viajando juntos, pudiendo La EMPRESA, con 96 HORAS corridas de anticipación a la fecha de salida, avisar la cancelación de las reservas si no se llegase a ese mínimo. Los señores pasajeros podrán optar por tomar otro destino o bien el reintegro de lo abonado sin indemnización ni gasto alguno.

              SUSPENSIÓN DE SERVICIOS POR CAUSAS DE FUERZA MAYOR.
              • La empresa se reserva el derecho de modificar fechas de realización del viaje contratado por el pasajero, en caso de causales de fuerza mayor que impidan el normal desarrollo del mismo.
              • Se otorgará al pasajero una NOTA DE CREDITO, por el total del importe abonado, para ser utilizada en fecha y destino que el pasajero seleccione.
              • El pasajero deberá abonar DIFERENCIA TARIFARIA en el caso de existir.

              RESPONSABILIDAD
              El organizador actúa como intermediario entre los viajeros y las compañías transportadoras, hoteles, receptivos, restaurantes, etc; siendo la responsabilidad cubierta por las instituciones apuntadas. En caso de que alguna situación escapare a estas condiciones: se tendrá en cuenta, estrictamente, lo anunciado por los vouchers (individual o grupal) que se entreguen al pasajero (en mano o vía web).
              DERECHOS Y DEBERES
              • La empresa se reserva el derecho de alterar y / 0 modificar itinerarios, fechas de salida / regreso, hoteles, excursiones y demás servicios contratados ante causas de fuerza mayor y / o caso fortuito que impidan el normal cumplimiento del mismo: corte de rutas, huracanes, inundaciones, reprogramación de eventos y / o cualquier otro factor ajeno a la responsabilidad de la Empresa que pueda significar un riesgo o una falta de servicio para el pasajero.
              • El organizador se reserva el derecho de variar el orden de los servicios, sustituyéndolo inclusive por otros similares.
              • El organizador se reserva el derecho de admisión y permanencia.
              • Al momento de contratación (por cualquier vía), se asumirá claramente que el pasajero conoce y acepta las condiciones enumeradas anteriormente.
              • El horario, punto de embarque y toda otra cuestión importante debe, obligatoria mente, confirmarse accediendo el pasajero al voucher grupal que se encontrara con una antelación de 48 horas en la web. Su no consulta libera de responsabilidad a la empresa por error en la información.
              BUTACAS
              1 - las butacas en parte baja del bus, solo serán pre-otorgadas en caso de presentar certificado de discapacidad vigente vía mail hasta 10 días anteriores a la fecha de salida, dependiendo de la disponibilidad existente en el caso de haber diferencia tarifaria (bus cama)
              2 - Se reservarán 02 asientos por cada certificado presentado, independientemente de la cantidad de pasajeros que componga el grupo de viaje.
              3 - Los certificados médicos NO son válidos para pre-reservar butaca. /Las butacas panorámicas NO se reservarán bajo ninguna circunstancia</p>
                        </td>
                        </tr>
                        </td>
                                </tbody>";

          $message .= "</table>";

          $message .= "</td></tr>";
          $message .= "</table>";

          $message .= "</body></html>";
          $mail->Body    =  $message;

    $mail->send();
    $disponible = intval($viaje["disponible"]) -  intval($cantidad);
    $fullday->update_fullday_reserva($disponible,$_GET["id"]);
    header('refresh:2; https://gnviajes.com.ar');
    echo '<script language="javascript">alert("Reserva creada con exito Te llegara un Mail con toda la informacion");</script>';
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link  rel="icon"   href="logo.png" type="image/png" />
    <title>GNViaje | Pasajeros</title>
  <link rel="stylesheet" href="../Components/styles.css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</head>

<body>
  <?php
  include('../Components/header.php')
  ?>
  <div class="form__contenedor mb-5">
    <section class="sec__title__promo mb-5 bg-pink-100">
      <div>
        <h1 class="text-xl font-bold text-pink-400">
          DETALLES DE LA RESERVA
        </h1>
      </div>
    </section>
    <section class="mb-5">
      <form action="" method="POST">
        <div class="bg-sky-100 p-3 rounded carda">
          <h2 class="text-sky-400 font-bold mb-2">
            Selecciona la cantidad de pasajeros
          </h2>
          <select class="bg-sky-200 rounded p-2 text-center" required name="pasajeros" id="pasajeros" onchange=handleChange()>
            <?php if($viaje["oferta"]== "2x1"){ ?>
              <option class="bg-sky-200" value="Seleccionar" selected>
              Seleccionar
            </option>  
              <option class="bg-sky-200" value="2x1" >
              2 Pasajeros
            </option>
            <option class="bg-sky-200" value="4x1">4 Pasajeros</option>
            <?php }else{ ?>
            <option class="bg-sky-200" value="Seleccionar" selected>
              Seleccionar
            </option>  
             <option class="bg-sky-200" value="2" >
              2 Pasajeros
            </option>
            <option class="bg-sky-200" value="3">3 Pasajeros</option>
            <option class="bg-sky-200" value="4">4 Pasajeros</option>
            <option class="bg-sky-200" value="5">5 Pasajeros</option>
            <?php } ?>
          </select>
        </div>
    </section>
    <section class="mb-5" id="form-info">
      <div class="informacion">
        <h2 class="p-4 informacion rounded text-center mb-3 font-bold text-yellow-500 bg-yellow-100">
          Completa los datos del formulario
        </h2>
      </div>
      <div class="pasajero bg-neutral-100 p-3 mt-2 rounded mb-5">
        <h2 class="font-bold text-center text-pink-400 mb-3">Pasajero 1</h2>
        <h2 class="font-bold text-center mb-2">Datos</h2>
        <div class="formulario__pasajero bg-neutral-200 rounded">
          <div class="dato-1">
            <label for="nombre">Nombre:</label>
            <input id="nombre" name="nombre" required type="text" placeholder="Coloca aquí tu nombre" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="apellido">Apellido:</label>
            <input id="apellido" name="apellido" required type="text" placeholder="Coloca aquí tu apellido" class="bg-neutral-50 rounded md:ml-1 p-1 w-full" />
            <div class="text-center">
              <label for="embarque" class="font-bold">Habitacion</label>
            </div>
            <select name="habitacion" required id="habitacion" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Doble Twink">Doble Twink (opcion 2 personas)</option>
              <option value="Matrimonial">Matrimonial (opcion 2 personas)</option>
              <option value="Triple Twink">Triple Twink (opcion 3 personas)</option>
              <option value="Cuadruple">Cuadruple (opcion 4 personas)</option>
              <option value="Triple y Doble">Triple y Doble (opcion 5 personas)</option>
              <option value="Full Day (no es necesario)">Full Day (no es necesario)</option>
            </select>
          </div>
          <div class="dato-2">
            <label for="celular">Celular:</label>
            <input id="celular" name="celular" required type="number" placeholder="Ej: 1122334455" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="dni">DNI/PASAPORTE:</label>
            <input id="dni" name="dni" type="number" required placeholder="Coloca aquí tu DNI/PASAPORTE" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-3">
            <label for="edad">Edad:</label>
            <input id="edad" name="edad" type="number" required placeholder="Ej: 24" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="fecha-nac">Fecha de nacimiento:</label>
            <input id="fecha-nac" name="fecha-nac" required type="date" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-4">
            <label for="nacionalidad">Nacionalidad:</label>
            <input id="nacionalidad" name="nacionalidad" type="text" required placeholder="Coloca aquí tu nacionalidad" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="email">Email:</label>
            <input id="email" required name="email" type="text"  placeholder="Ej: correo@correo.com" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-5">
            <div class="text-center">
              <label for="comida" class="font-bold">REGIMEN DE COMIDA</label>
            </div>
            <select name="comida" id="comida" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" " >- Seleccionar -</option>
              <option value="Apto Carne">Apto Carne</option>
              <option value="Vegetariano">Vegetariano</option>
              <option value="Vegano">Vegano</option>
              <option value="Celiaco">Celíaco</option>
            </select>
          </div>
          <div class="dato-6">
            <div class="text-center">
              <label for="embarque" class="font-bold">PUERTA DE EMBARQUE</label>
            </div>
            <select name="embarque" required id="embarque" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Varela">Varela - av Calchaqui 686</option>
              <option value="Lavallol">Lavallol - YPF Rotonda Lavallol</option>
              <option value="Lanus">Lanus - YPF Av Hipolito Yrigoyen 3740</option>
              <option value="Avellaneda">Avellaneda - SHELL Av Hipolito Yrigoyen 345</option>
              <option value="Dellepiane">Dellepiane - Av P. Moreno 3950</option>
              <option value="San Justo">San Justo - Terminal Av M. Buffano 3352</option>
              <option value="Moron">Moron - GNC Vergara y Gaona</option>
              <option value="Pacheco">Pacheco - Parador El Turista</option>
            </select>
            <div class="text-center">
              <label for="extra" class="font-bold">DATOS EXTRA</label>
            </div>
            <textarea name="extra" id="extra" name="extra" class="rounded p-2" placeholder="Escribe aquí algo que quieras comentarnos"></textarea>
          </div>
        </div>
      </div>
      <div class="pasajero bg-neutral-100 p-3 mt-2 rounded mb-5">
        <h2 class="font-bold text-center text-pink-400 mb-3">Pasajero 2</h2>
        <h2 class="font-bold text-center mb-2">Datos</h2>
        <div class="formulario__pasajero bg-neutral-200 rounded">
          <div class="dato-1">
            <label for="nombre2">Nombre:</label>
            <input id="nombre2" name="nombre2" type="text" required placeholder="Coloca aquí tu nombre" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="apellido2">Apellido:</label>
            <input id="apellido2" name="apellido2" type="text" required placeholder="Coloca aquí tu apellido" class="bg-neutral-50 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-2">
            <label for="celular2">Celular:</label>
            <input id="celular2" name="celular2" type="number" required placeholder="Ej: 1122334455" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="dni2">DNI/PASAPORTE:</label>
            <input id="dni2" name="dni2" type="text" required placeholder="Coloca aquí tu DNI/PASAPORTE" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-3">
            <label for="edad2">Edad:</label>
            <input name="edad2" id="edad2" type="number"  required placeholder="Ej: 24" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="fecha-nac2">Fecha de nacimiento:</label>
            <input id="fecha-nac2" name="fecha-nac2"  required type="date" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />

          </div>
          <div class="dato-4">
            <label for="nacionalidad2">Nacionalidad:</label>
            <input id="nacionalidad2" name="nacionalidad2"  required type="text" placeholder="Coloca aquí tu nacionalidad" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-5">
            <div class="text-center">
              <label for="comida2" class="font-bold">REGIMEN DE COMIDA</label>
            </div>
            <select name="comida2" required  id="comida2" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" " >- Seleccionar -</option>
              <option value="Apto Carne">Apto Carne</option>
              <option value="Vegetariano">Vegetariano</option>
              <option value="Vegano">Vegano</option>
              <option value="Celiaco">Celíaco</option>
            </select>
          </div>
          <div class="dato-6">
            <div class="text-center">
              <label for="embarque2"  class="font-bold">PUERTA DE EMBARQUE</label>
            </div>
            <select name="embarque2" required id="embarque2" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Varela">Varela - av Calchaqui 686</option>
              <option value="Lavallol">Lavallol - YPF Rotonda Lavallol</option>
              <option value="Lanus">Lanus - YPF Av Hipolito Yrigoyen 3740</option>
              <option value="Avellaneda">Avellaneda - SHELL Av Hipolito Yrigoyen 345</option>
              <option value="Dellepiane">Dellepiane - Av P. Moreno 3950</option>
              <option value="San Justo">San Justo - Terminal Av M. Buffano 3352</option>
              <option value="Moron">Moron - GNC Vergara y Gaona</option>
              <option value="Pacheco">Pacheco - Parador El Turista</option>
            </select>
            <div class="text-center">
              <label for="extra2" class="font-bold">DATOS EXTRA</label>
            </div>
            <textarea name="extra2" id="extra2" class="rounded p-2" placeholder="Escribe aquí algo que quieras comentarnos"></textarea>
          </div>
        </div>
      </div>
      <div class="pasajero pass3 bg-neutral-100 hidden p-3 mt-2 rounded mb-5">
        <h2 class="font-bold text-center text-pink-400 mb-3">Pasajero 3</h2>
        <h2 class="font-bold text-center mb-2">Datos</h2>
        <div class="formulario__pasajero bg-neutral-200 rounded">
          <div class="dato-1">
            <label for="nombre3">Nombre:</label>
            <input id="nombre3" name="nombre3" type="text" placeholder="Coloca aquí tu nombre" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="apellido3">Apellido:</label>
            <input id="apellido3" name="apellido3" type="text" placeholder="Coloca aquí tu apellido" class="bg-neutral-50 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-2">
            <label for="dni3">DNI:</label>
            <input id="dni3" name="dni3" type="text" placeholder="Coloca aquí tu DNI/PASAPORTE" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-3">
            <label for="edad3">Edad:</label>
            <input id="edad3" name="edad3" type="number" placeholder="Ej: 24" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="fecha-nac">Fecha de nacimiento:</label>
            <input id="fecha-nac3" name="fecha-nac3" type="date" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-4">
            <label for="nacionalidad3">Nacionalidad:</label>
            <input id="nacionalidad3" name="nacionalidad3" type="text" placeholder="Coloca aquí tu nacionalidad" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-5">
            <div class="text-center">
              <label for="comida3" class="font-bold">REGIMEN DE COMIDA</label>
            </div>
            <select name="comida3" id="comida3" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value="nosec">- Seleccionar -</option>
              <option value="Apto Carne">Apto Carne</option>
              <option value="Vegetariano">Vegetariano</option>
              <option value="Vegano">Vegano</option>
              <option value="Celiaco">Celíaco</option>
            </select>
          </div>
          <div class="dato-6">
            <div class="text-center">
              <label for="embarque3" class="font-bold">ASCENSO / EMBARQUE</label>
            </div>
            <select name="embarque3" id="embarque3" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Varela">Varela - av Calchaqui 686</option>
              <option value="Lavallol">Lavallol - YPF Rotonda Lavallol</option>
              <option value="Lanus">Lanus - YPF Av Hipolito Yrigoyen 3740</option>
              <option value="Avellaneda">Avellaneda - SHELL Av Hipolito Yrigoyen 345</option>
              <option value="Dellepiane">Dellepiane - Av P. Moreno 3950</option>
              <option value="San Justo">San Justo - Terminal Av M. Buffano 3352</option>
              <option value="Moron">Moron - GNC Vergara y Gaona</option>
              <option value="Pacheco">Pacheco - Parador El Turista</option>
            </select>
            <div class="text-center">
              <label for="extra3" class="font-bold">DATOS EXTRA</label>
            </div>
            <textarea name="extra3" id="extra3" class="rounded p-2" placeholder="Escribe aquí algo que quieras comentarnos"></textarea>
          </div>
        </div>
      </div>
      <div class="pasajero pass4 bg-neutral-100 hidden p-3 mt-2 rounded mb-5">
        <h2 class="font-bold text-center text-pink-400 mb-3">Pasajero 4</h2>
        <h2 class="font-bold text-center mb-2">Datos</h2>
        <div class="formulario__pasajero bg-neutral-200 rounded">
          <div class="dato-1">
            <label for="nombre4">Nombre:</label>
            <input id="nombre4" name="nombre4" type="text" placeholder="Coloca aquí tu nombre" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="apellido4">Apellido:</label>
            <input id="apellido4" name="apellido4" type="text" placeholder="Coloca aquí tu apellido" class="bg-neutral-50 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-2">
            <label for="dni4">DNI/PASAPORTE:</label>
            <input id="dni4" name="dni4" type="text" placeholder="Coloca aquí tu DNI/PASAPORTE" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-3">
            <label for="edad4">Edad:</label>
            <input id="edad4" name="edad4" type="number" placeholder="Ej: 24" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="fecha-nac4">Fecha de nacimiento:</label>
            <input id="fecha-nac4" name="fecha-nac4" type="date" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-4">
            <label for="nacionalidad4">Nacionalidad:</label>
            <input id="nacionalidad4" name="nacionalidad4" type="text" placeholder="Coloca aquí tu nacionalidad" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-5">
            <div class="text-center">
              <label for="comida4" class="font-bold">REGIMEN DE COMIDA</label>
            </div>
            <select name="comida4" id="comida4" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Apto Carne">Apto Carne</option>
              <option value="Vegetariano">Vegetariano</option>
              <option value="Vegano">Vegano</option>
              <option value="Celiaco">Celíaco</option>
            </select>
          </div>
          <div class="dato-6">
            <div class="text-center">
              <label for="embarque4" class="font-bold">PUERTA DE EMBARQUE</label>
            </div>
            <select name="embarque4" id="embarque4" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Varela">Varela - av Calchaqui 686</option>
              <option value="Lavallol">Lavallol - YPF Rotonda Lavallol</option>
              <option value="Lanus">Lanus - YPF Av Hipolito Yrigoyen 3740</option>
              <option value="Avellaneda">Avellaneda - SHELL Av Hipolito Yrigoyen 345</option>
              <option value="Dellepiane">Dellepiane - Av P. Moreno 3950</option>
              <option value="San Justo">San Justo - Terminal Av M. Buffano 3352</option>
              <option value="Moron">Moron - GNC Vergara y Gaona</option>
              <option value="Pacheco">Pacheco - Parador El Turista</option>
            </select>
            <div class="text-center">
              <label for="extra4" class="font-bold">DATOS EXTRA</label>
            </div>
            <textarea name="extra4" id="extra4" class="rounded p-2" placeholder="Escribe aquí algo que quieras comentarnos"></textarea>
          </div>
        </div>
      </div>
      <div class="pasajero pass5 bg-neutral-100 hidden p-3 mt-2 rounded mb-5">
        <h2 class="font-bold text-center text-pink-400 mb-3">Pasajero 5</h2>
        <h2 class="font-bold text-center mb-2">Datos</h2>
        <div class="formulario__pasajero bg-neutral-200 rounded">
          <div class="dato-1">
            <label for="nombre5">Nombre:</label>
            <input id="nombre5" name="nombre5" type="text" placeholder="Coloca aquí tu nombre" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="apellido5">Apellido:</label>
            <input id="apellido5" name="apellido5" type="text" placeholder="Coloca aquí tu apellido" class="bg-neutral-50 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-2">
            <label for="dni5">DNI:</label>
            <input id="dni5" name="dni5" type="text" placeholder="Coloca aquí tu DNI/PASAPORTE" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-3">
            <label for="edad5">Edad:</label>
            <input id="edad5" name="edad5" type="number" placeholder="Ej: 24" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
            <label for="fecha-nac5">Fecha de nacimiento:</label>
            <input id="fecha-nac5" name="fecha-nac5" type="date" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-4">
            <label for="nacionalidad5">Nacionalidad:</label>
            <input id="nacionalidad5" name="nacionalidad5" type="text" placeholder="Coloca aquí tu nacionalidad" class="bg-neutral-50 mb-2 rounded md:ml-1 p-1 w-full" />
          </div>
          <div class="dato-5">
            <div class="text-center">
              <label for="comida5" class="font-bold">REGIMEN DE COMIDA</label>
            </div>
            <select name="comida5" id="comida5" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Apto Carne">Apto Carne</option>
              <option value="Vegetariano">Vegetariano</option>
              <option value="Vegano">Vegano</option>
              <option value="Celiaco">Celíaco</option>
            </select>
          </div>
          <div class="dato-6">
            <div class="text-center">
              <label for="embarque5" class="font-bold">PUERTA DE EMBARQUE</label>
            </div>
            <select name="embarque5" id="embarque5" class="w-full rounded p-1 mb-2 bg-neutral-50 text-center">
              <option value=" "  >- Seleccionar -</option>
              <option value="Varela">Varela - av Calchaqui 686</option>
              <option value="Lavallol">Lavallol - YPF Rotonda Lavallol</option>
              <option value="Lanus">Lanus - YPF Av Hipolito Yrigoyen 3740</option>
              <option value="Avellaneda">Avellaneda - SHELL Av Hipolito Yrigoyen 345</option>
              <option value="Dellepiane">Dellepiane - Av P. Moreno 3950</option>
              <option value="San Justo">San Justo - Terminal Av M. Buffano 3352</option>
              <option value="Moron">Moron - GNC Vergara y Gaona</option>
              <option value="Pacheco">Pacheco - Parador El Turista</option>
            </select>
            <div class="text-center">
              <label for="extra5" class="font-bold">DATOS EXTRA</label>
            </div>
            <textarea name="extra5" id="extra5" class="rounded p-2" placeholder="Escribe aquí algo que quieras comentarnos"></textarea>
          </div>
        </div>
      </div>
    </section>
    <section class="bg-neutral-50 p-2 rounded">
      <div class="pago__container">
        <div class="info_2 mb-5">
          <h2 class="font-bold text-pink-400 text-center mb-2">
            El total a pagar es de
          </h2>
          <p class="font-bold text-center" id="total">$<?php echo $viaje["precio"] ?></p>
        <?php  if($viaje["oferta"] =="2x1"){ ?>
          <p class="font-bold text-center" id="ofertaS">Oferta <?php echo $viaje["oferta"] ?> </p>
         <?php }else{ ?>

         <?php } ?>

        </div>
      </div>
      <div class="info_detalles mb-5">
        <h2 class="font-bold text-pink-400 text-center mb-2">
          Detalles de la reserva
        </h2>
        <ul>
          <li class="text-xs md:text-base">
            <b>Destino:</b><?php echo $viaje["titulo"] ?>
          </li>
          <li class="text-xs md:text-base">
            <b>Fecha de salida:</b> <?php echo  date("d/m/Y", strtotime($viaje["fecha"])); ?>
          </li>
          <li class="text-xs md:text-base">
            <strong>Valor del paquete por persona:</strong>
            <b id="precio" name="precio" class="font-bold text-pink-400"><?php echo $viaje["precio"] ?></b>
            <input type="text" hidden id="precioT" name="precioT" value="<?php echo $viaje["precio"] ?>">
          </li>
        </ul>
      </div>
      <div class="confirmar_reserva">
        <button type="submit" disabled name="btnPOST" id="btnPOST" class="w-full p-3 bg-pink-100 hover:bg-pink-200 text-pink-400 font-bold rounded">
          Confirmar Reserva
        </button>
      </div>
      </form>
    </section>
  </div>
  <?php
  include('../Components/footer.php')
  ?>
  <script src="index.js"></script>
</body>

</html>