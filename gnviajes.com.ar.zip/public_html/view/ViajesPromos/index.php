<?php
require_once("../../config/conexion.php"); 
require_once("../../models/Viaje.php"); 
$fullday= new Fullday();

$datos=$fullday->get_fullday_x_slug($_GET["id"]);







?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../Components/styles.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
      crossorigin="anonymous"
    />
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
      crossorigin="anonymous"
    ></script>
    <link  rel="icon"   href="logo.png" type="image/png" />
    <title>GNViaje | Viajes</title>
  </head>
  <body>
    <div class="back">
      <?php 
        include('../Components/header.php')
      ?>
      <section class="sec__title__promo mb-5 bg-pink-500">
        <div>
          <h1 class="text-xl font-bold text-yellow-400">PROMOCIONES ESPECIALES</h1>
        </div>
      </section>
      <div class="contenedor">
        <section class="grilla">
          <?php 
            $arry=array();
            
            foreach($datos  as $viaj){
              if(in_array($viaj["titulo"], $arry)){
              
              }
              else{ 
                
              ?>
              
                <div class="col-sm-4">
                  <div
                    class="card bg-pink-600 viaje__container pb-2 flex justify-center content-center relative"
                  >
                    <img
                      class="card-img-top"
                      src="<?php echo $viaj["imagen"]; ?>"
                      alt="design image"
                    />
  
                    <div class="card-body">
                    <h5 class="card-title text-white font-bold">
                      <?php echo $viaj["titulo"]; ?>
                    </h5>
                    <!-- <p class="card-text text-white">
                      Fecha de Viaje: 
                      <!-- <b class="text-yellow-400"><?php echo $viaj["fecha"]; ?></b> -->
                      <!-- <b class="text-yellow-400">Click en reservar para ver fechas disponibles</b> -->
                    </p> 
                    <p class="card-text text-white">
                      Disponibilidad:
                      <b class="text-yellow-400"><?php echo $viaj["disponible"]; ?> lugares disponibles</b>
                    </p>
                    <p class="card-text text-white">
                      Precio:
                      <b class="text-yellow-400 text-xl">$ <?php echo $viaj["precio"]; ?></b>
                    </p>
                    <a
                      href="../ReservaViajes?id=<?php echo $viaj["slug"]; ?>&titu=<?php echo $viaj["idTitulo"]; ?>"
                      class="btn mt-4 font-bold cursor-pointer hover:bg-yellow-500 z-10 btn-color text-white rounded bg-yellow-400 w-full mt-1"
                      >Reservar Viaje</a
                    >
                  </div>                
                  </div>
                </div>
                <?php        
              }
              array_push($arry,$viaj["titulo"]);
            }
                ?>
        </section>
      </div>
      <?php 
        include('../Components/footer.php')
      ?>
    </div>
  </body>
</html>
