
 <nav class="side-menu">
	<ul class="side-menu-list">
		<li class="blue-dirty">
			<a href="..\Home\">
				<span class="glyphicon glyphicon-th"></span>
				<span class="lbl">Inicio</span>
			</a>
		</li>
		
	
		<li class="grey with-sub">
			<span>
				<span class="font-icon font-icon-burger"></span>
				<span class="lbl">Menu</span>
			</span>
			<ul>
				
			
				<li class="with-sub">
					<span>
						<span class="lbl">Obras</span>
					</span>
					<ul>
					<li><a href="..\Obras\"><span class="lbl">Listado/Agregar</span></a></li>			
					</ul>
			
			
					
			
					
				</li>
			
				
			</ul>


		</li>
	
	</ul>

</nav>

<nav class="side-menu">
	<ul class="side-menu-list">
		<!-- <li class="blue-dirty">
			<a href="..\Home\">
				<span class="glyphicon glyphicon-th"></span>
				<span class="lbl">Inicio</span>
			</a>
		</li> -->
		
	
		<li class="grey with-sub">
			<span>
				<span class="font-icon font-icon-burger"></span>
				<span class="lbl">Menu</span>
			</span>
			<ul>
				
				<li class="with-sub">
					<span>
						<span class="lbl">Viajes</span>
					</span>
					<ul>
					<li><a href="..\Viajes\"><span class="lbl">Listado/Agregar</span></a></li>			
					</ul>
			
			
					
			
					
				</li>
				<?php if($_SESSION["rol_id"]==2){ ?>
						<li class="with-sub">
					<span>
						<span class="lbl">Usuarios</span>
					</span>
					<ul>
					<li><a href="..\Usuarios\"><span class="lbl">Listado/Agregar</span></a></li>			
					</ul>
			
			
					
			
					
				</li>
				<?php }  ?>	
				<?php if($_SESSION["rol_id"]==2){ ?>
						<li class="with-sub">
					<span>
						<span class="lbl">Banners</span>
					</span>
					<ul>
					<li><a href="..\Banners\"><span class="lbl">Listado/Agregar</span></a></li>			
					</ul>
			
			
					
			
					
				</li>
				<?php }  ?>
			</ul>


		</li>
	
	</ul>

</nav>
