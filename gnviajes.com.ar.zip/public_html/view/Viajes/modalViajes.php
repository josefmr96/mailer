<div id="modalViajes" class="modal fade bd-example-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="modal-close" data-dismiss="modal" aria-label="Close">
                    <i class="font-icon-close-2"></i>
                </button>
                <h4 class="modal-title" id="mdltitulo"></h4>
            </div>
            <form method="post" id="usuario_form">
                <div class="modal-body">
                    <input id="idfullday" hidden name="idfullday" value="">
                    <div class="form-group">
                        <label class="form-label" for="titulo">Titulo</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Titulo del viaje" required>
                    </div>     
                    <div class="form-group">
                        <label class="form-label" for="precio">Precio</label>
                        <input type="number" class="form-control" id="precio" name="precio" placeholder="" required>
                    </div> 
                     <div class="form-group">
                        <label class="form-label" for="fecha">Fecha de Salida</label>
                        <input type="date" class="form-control" id="fecha" name="fecha" placeholder="" required>
                    </div> 
                    <div class="form-group">
                        <label class="form-label" for="descripcion">Descripcion</label>
                        <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="" required>
                    </div>  
                      <div class="form-group">
                        <label class="form-label" for="imagen">Imagen</label>
                        <input type="text" class="form-control" id="imagen" name="imagen" placeholder="Titulo del viaje" required>
                    </div> 
                    <div class="form-group">
                        <label class="form-label" for="slug">Referencia</label>
                        <select class="form-control" name="slug" id="slug">
                            <?php foreach($datosBane as $bann){ ?>
                            <option value="<?php echo $bann["slug"] ?>"> <?php echo $bann["slug"] ?></option>

                            <?php } ?>
                        </select>
                    </div> 
                      <div class="form-group">
                        <label class="form-label" for="disponible">Disponibles</label>
                        <input type="number" class="form-control" id="disponible" name="disponible" placeholder="" required>
                    </div>   
                    <div class="form-group">
                        <label class="form-label" for="excursiones">Excursiones</label>
                        <input type="text" class="form-control" id="excursiones" name="excursiones" placeholder="" >
                    </div>   
                     <div class="form-group">
                        <label class="form-label" for="oferta">Oferta</label>
                        <select class="form-control" name="oferta" id="oferta">
                            
                            <option value="sin oferta"> sin oferta</option>
                            <option value="2x1"> 2x1</option>
                            <option value="4x3"> 4x3</option>


                        </select>
                    </div>   

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-rounded btn-default" data-dismiss="modal">Cerrar</button>
                    <button type="submit" name="action" id="#" value="add" class="btn btn-rounded btn-primary">Guardar</button>
                </div>
                </div>
            </form>
        </div>
    </div>
</div>