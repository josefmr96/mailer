<header class="site-header">
    <div class="container-fluid">

        <a href="#" class="site-logo">
            <h1 style="    color: #ffffff;
    font-weight: 900;
    background-color: #39508e;">GNVIAJES</h1>
        </a>

        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
            <span>toggle menu</span>
        </button>

        <button class="hamburger hamburger--htla">
            <span>toggle menu</span>
        </button>
        
        <div class="site-header-content">
            <div class="site-header-content-in">
                <div class="site-header-shown">
                    <div class="dropdown user-menu">
                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           
                        </button>  
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd-user-menu">
                            <a class="dropdown-item" href="../Logout/logout.php"><span class="font-icon glyphicon glyphicon-log-out"></span>Cerrar Sesion</a>
                        </div>
                        </span>
                    </div>
                </div>
                
                <input type="text" hidden name="rol_idx" id="rol_idx" value="<?php echo $_SESSION["rol_id"] ?>">
               <input type="text" hidden name="usu_idx" id="usu_idx" value="<?php echo $_SESSION["usu_id"] ?>">
                <div class="mobile-menu-right-overlay"></div>

         

                <div class="dropdown dropdown-typical">
                    <a href="#" class="dropdown-toggle no-arr">
                        
                    <span class="label label-pill label-info"><?php echo  $_SESSION["usu_nom"]; ?>
                      
                    </a>
                </div>

            </div>
        </div>
    </div>
</header>