<?php
    require_once("../../config/conexion.php");
    require_once("../../models/Reserva.php");  
    require_once("../../models/Viaje.php");  
    $reserva = new Reserva();
    $viaje = new Fullday();

    switch($_GET["op"]){ //reserva
        case "guardaryeditar": //en caso de que sea guardar o editar
            $datos=$viaje->get_fullday_x_id(intval($_GET["tvl"]));
            foreach($datos as $row){
                
            }
            
            
            if(empty($_POST["idreserva"])){     //si viene vacio el id se inserta
                $disponible=intval($row["disponible"])-1;
                $viaje->update_fullday_reserva($disponible,intval($_GET["tvl"]));
                $reserva->insert_reserva(
                    $_POST["nombre"],
                    $_POST["apellido"],    
                    $_POST["fecha_nac"],    
                    $_POST["nacionalidad"],    
                    intval($_POST["dni"]),
                    $_POST["observaciones"],
                    intval($_POST["terminal"]),
                    intval($_GET["id"]),
                    intval($_GET["tvl"]),
                    $_POST["cupon"]
               );   
            } else {
                $reserva->update_reserva( //caso contrario se actualiza el usuario seleccionado
                    $_POST["nombre"],
                    $_POST["apellido"],    
                    $_POST["fecha_nac"],    
                    $_POST["nacionalidad"],    
                    intval($_POST["dni"]),
                    $_POST["observaciones"],
                    intval($_POST["terminal"]),
                    intval($_POST["idreserva"]));
                  
            }
        break;

        case "listar": //listado de usuarios en grilla
            $datos=$reserva->obtener_reserva($_GET["id"],$_GET["tvl"]); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["cupon"];
                $sub_array[] = $row["nombre"].' '.$row["apellido"];
                $sub_array[] = $row["dni"];
                $sub_array[] = $row["fecha_nac"];
                $sub_array[] = $row["nacionalidad"];
                $sub_array[] = $row["terminal"];
                $sub_array[] = $row["observaciones"];
                $sub_array[] = '<button type="button" onClick="agregarPago('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-primary btn-sm ladda-button">Agregar</button>';
                $sub_array[] = '<button type="button" onClick="editar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-warning btn-sm ladda-button"><i class="fa fa-edit"></i></button>';
                $sub_array[] = '<button type="button" onClick="eliminar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results); 
        break;    
        case "listarTodo": //listado de RESERVAS CORRESPONDIENTE A UN VIAJE EN ESPECIFICO 
            //FILTRADO POR ID 
            //////NT///////
            $datos=$reserva->obtener_reserva($_GET["id"]); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["cupon"];
                $sub_array[] = $row["cantidad"];
                $sub_array[] = $row["total"];
                $sub_array[] = $row["correo"];
                $sub_array[] = $row["telefono"];
                $sub_array[] = $row["titulo"].' '.$newDate = date("d/m/Y", strtotime($row["fecha"]));
                // $sub_array[] = '<button type="button" onClick="agregarPago('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-primary btn-sm ladda-button">Agregar</button>';
                // $sub_array[] = '<button type="button" onClick="editar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-warning btn-sm ladda-button"><i class="fa fa-edit"></i></button>';
                // $sub_array[] = '<button type="button" onClick="eliminar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results); 
        break;    
        case "pasajeros": //listado de PASAJEROS POR VIAJE
            //LISTADO DE TODOS LOS PASAJEROS
            //////NT///////
            $datos=$reserva->obtener_pasajeros($_GET["id"]); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["nombre"];
                $sub_array[] = $row["apellido"];
                $sub_array[] = $row["dni"];
                $sub_array[] = $row["fecha_nac"];
                $sub_array[] = $row["nacionalidad"];
                $sub_array[] = $row["edad"];
                $sub_array[] = $row["terminal"];
                $sub_array[] = $row["cupon"];
                $sub_array[] = $row["observacion"];
                $sub_array[] = $row["comida"];
               
                // $sub_array[] = '<button type="button" onClick="agregarPago('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-primary btn-sm ladda-button">Agregar</button>';
                // $sub_array[] = '<button type="button" onClick="editar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-warning btn-sm ladda-button"><i class="fa fa-edit"></i></button>';
                // $sub_array[] = '<button type="button" onClick="eliminar('.$row["idreserva"].');"  id="'.$row["idreserva"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results); 
        break;

        case "eliminar": //Eliminar usuarios
            $datos=$viaje->get_fullday_x_id(intval($_GET["tvl"]));
        
            foreach($datos as $row){
                
            }
            $disponible=intval($row["disponible"])+1;
            if($disponible){
                $viaje->update_fullday_reserva($disponible,intval($_GET["tvl"]));
                $reserva->delete_reserva($_POST["idreserva"]);
            }
                
         
        break;

        case "mostrar"; // Obtenemos los datos del usuario que se va a actualizar
            $datos=$reserva->get_reserva_x_id($_POST["idreserva"]);  
            if(is_array($datos)==true and count($datos)>0){
                foreach($datos as $row) //Llenar datos de modal
                {
                    $output["idreserva"] = $row["idreserva"];
                    $output["cupon"] = $row["cupon"];
                    $output["nombre"] = $row["nombre"];
                    $output["apellido"] = $row["apellido"];
                    $output["dni"] = $row["dni"];
                    $output["fecha_nac"] = $row["fecha_nac"];
                    $output["nacionalidad"] = $row["nacionalidad"];
                    $output["observaciones"] = $row["observaciones"];
                    $output["fk_terminal"] = $row["fk_terminal"];
                    $output["terminal"] = $row["terminal"];
                }
                echo json_encode($output); //pasar datos a formato json
            }   
        break;  
        case "agregarPago"; // Obtenemos los datos del usuario que se va a actualizar
           $viaje= intval($_GET["full"]);
           $usuario= intval($_GET["ux"]);
           $reservaXd= intval($_POST["idreservaXd"]);
           $reserva->insert_pagos(
               $reservaXd,
               $usuario,
               $viaje,
               $_POST["observaciones"],
               $_POST["cantidad"],
            $_POST["metodo"],
           $_POST["numero_comprobante"]
           );
        break; 
        case "listarPagos"; // Obtenemos los datos del usuario que se va a actualizar
           $reservaXd= intval($_GET["id"]);
           $datos=$reserva->obtener_pagos($reservaXd); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["metodo"];
                $sub_array[] = $row["cantidad"];
                $sub_array[] = $row["numero_comprobante"];
                $sub_array[] = $row["observaciones"];
            //$sub_array[] = '<button type="button" onClick="eliminarPago('.$row["idpago"].');"  id="'.$row["idpago"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results);
        break;


    

   

   
 
    }
?>