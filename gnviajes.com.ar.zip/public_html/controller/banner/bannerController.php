<?php
    require_once("../../config/conexion.php");
    require_once("../../models/Banner.php");  
    $banner = new Banner();

    switch($_GET["op"]){ //banner
        case "guardaryeditar": //en caso de que sea guardar o editar
            if(empty($_POST["idpromo"])){     //si viene vacio el id se inserta
                $banner->insert_Banner(
                    $_POST["titulo"],
                    $_POST["slug"],    
                    $_POST["url"],
                    $_POST["estado"]
                );     
            }
        break;

        case "listar": //listado de usuarios en grilla
            $datos=$banner->obtener_Banner(); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["titulo"];
                $sub_array[] = $row["slug"];
                $sub_array[] = $row["url"];
                $sub_array[] = $row["estado"];
                $sub_array[] = '<button type="button" onClick="eliminar('.$row["idpromo"].');"  id="'.$row["idpromo"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results);
        break;

        case "eliminar": //Eliminar usuarios
            $banner->delete_Banner($_POST["idpromo"]);
        break;

        case "mostrar"; // Obtenemos los datos del usuario que se va a actualizar
            $datos=$banner->get_banner_x_id($_POST["idbanner"]);  
            if(is_array($datos)==true and count($datos)>0){
                foreach($datos as $row) //Llenar datos de modal
                {
                    $output["titulo"] = $row["titulo"];
                    $output["precio"] = $row["precio"];
                    $output["fecha"] = $row["fecha"];
                    $output["disponible"] = $row["disponible"];
                    $output["descripcion"] = $row["descripcion"];
                    $output["slug"] = $row["slug"];
                    $output["imagen"] = $row["imagen"];
                }
                echo json_encode($output); //pasar datos a formato json
            }   
        break;


    

   

   
 
    }
?>