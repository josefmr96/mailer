<?php
    require_once("../../config/conexion.php");
    require_once("../../models/Viaje.php");  
    $fullday = new Fullday();

    switch($_GET["op"]){ //fullday
        case "guardaryeditar": //en caso de que sea guardar o editar
            var_dump( $_POST["idfullday"]);
            if(empty($_POST["idfullday"])){     //si viene vacio el id se inserta
                $fullday->insert_fullday(
                    $_POST["titulo"],
                    $_POST["precio"],    
                    $_POST["fecha"],    
                    $_POST["disponible"],    
                    $_POST["descripcion"],
                    $_POST["slug"],
                    $_POST["imagen"],
                    $_POST["excursiones"],
                    trim($_POST["titulo"]),
                    $_POST["oferta"]
                );     
            } else {
                $fullday->update_fullday( //caso contrario se actualiza el usuario seleccionado
                    $_POST["titulo"],
                    $_POST["precio"],    
                    $_POST["fecha"],    
                    $_POST["disponible"],    
                    $_POST["descripcion"],
                    $_POST["slug"],
                    $_POST["imagen"],
                    $_POST["idfullday"],
                    $_POST["excursiones"],
                    trim($_POST["titulo"]),
                    $_POST["oferta"]
                );  
                  
            }
        break;

        case "listar": //listado de usuarios en grilla
            $datos=$fullday->obtener_fullday(); //obtener todos los usuarios
            $data= Array();
            foreach($datos as $row){
                $sub_array = array();
                $sub_array[] = $row["titulo"];
                $sub_array[] = $row["precio"];
                $sub_array[] = $row["fecha"];
                $sub_array[] = $row["disponible"];
                $sub_array[] ='<a type="button"  href="../Reservar?id='.$row["idfullday"].'" class="btn btn-inline btn-primary btn-sm ladda-button">Reservar</a>';
                $sub_array[] = $row["excursiones"];
                //botones dinamicos para Editar y elimnar
                $sub_array[] ='<a type="button"  href="../Pasajeros?id='.$row["idfullday"].'" class="btn btn-inline btn-primary btn-sm ladda-button">Pasajeros</a>';
                $sub_array[] = '<button type="button" onClick="editar('.$row["idfullday"].');"  id="'.$row["idfullday"].'" class="btn btn-inline btn-warning btn-sm ladda-button"><i class="fa fa-edit"></i></button>';
                $sub_array[] = '<button type="button" onClick="eliminar('.$row["idfullday"].');"  id="'.$row["idfullday"].'" class="btn btn-inline btn-danger btn-sm ladda-button"><i class="fa fa-trash"></i></button>';
                $data[] = $sub_array;
            }

            $results = array(
                "sEcho"=>1,
                "iTotalRecords"=>count($data),
                "iTotalDisplayRecords"=>count($data),
                "aaData"=>$data);
            echo json_encode($results);
        break;

        case "eliminar": //Eliminar usuarios
            $fullday->delete_fullday($_POST["idfullday"]);
        break;

        case "mostrar"; // Obtenemos los datos del usuario que se va a actualizar
            $datos=$fullday->get_fullday_x_id($_POST["idfullday"]);  
            if(is_array($datos)==true and count($datos)>0){
                foreach($datos as $row) //Llenar datos de modal
                {
                    $output["titulo"] = $row["titulo"];
                    $output["precio"] = $row["precio"];
                    $output["fecha"] = $row["fecha"];
                    $output["disponible"] = $row["disponible"];
                    $output["descripcion"] = $row["descripcion"];
                    $output["slug"] = $row["slug"];
                    $output["imagen"] = $row["imagen"];
                }
                echo json_encode($output); //pasar datos a formato json
            }   
        break;


    

   

   
 
    }
?>