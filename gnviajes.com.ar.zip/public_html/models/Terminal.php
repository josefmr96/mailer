
<?php
                                        /*Modelo de la Clase terminal */
class Terminal extends Conectar{
/* 
    Obtenemos todos los terminales segun el usuario que lo creo 
*/
    public function obtener_terminales(){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM terminales where estado =1;";
            $sql=$conectar->prepare($sql);
            $sql->execute();
            return $resultado=$sql->fetchAll();
    }  
/* 
    Obtenemos los terminales que el usuario haya creado y el id sea el cual especificamos
        $idterminal: terminal seleccionado a filtrar
        $fk_usuario: usuario que lo creo 
*/
    public function obtener_terminales_elemnto($idterminal,$fk_usuario){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM terminales where estado =1
        AND idterminal = ?
        AND fk_usuario = ?;";
            $sql=$conectar->prepare($sql);
            $sql->bindValue(1, $idterminal);
            $sql->bindValue(2, $fk_usuario);
            $sql->execute();
            return $resultado=$sql->fetchAll();
    }   
/*
    Obtenemos el {ID} del terminal seleccionar segun su nombre y usuario creador
*/
    public function obtener_id_terminal($fk_usuario,$terminal){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="SELECT * FROM terminales where estado =1
        AND fk_usuario = ?
        AND terminal= ?;";
            $sql=$conectar->prepare($sql);
            $sql->bindValue(1, $fk_usuario);
            $sql->bindValue(2, $terminal);
            $sql->execute();
            return $resultado=$sql->fetchAll();
    }
/*
    Creamos nuevo terminal y asignamos el usuario creador del mismo
*/
    public function insertar_terminal($fk_sensor,$terminal,$fk_usuario){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="INSERT INTO terminales
         (idterminal, fk_sensor, terminal, estado, fk_usuario) VALUES (NULL,?,?,1,?);";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $fk_sensor);
        $sql->bindValue(2, $terminal);
        $sql->bindValue(3, $fk_usuario);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    } 
/*
    Obtenemos el {ID} del terminal creado el cual tiene que coincidir con la {descripcion} y {terminales}
*/
    public function get_id_terminales_insert($terminales,$descripcion){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="SELECT idterminal FROM terminales WHERE terminales = ? AND  descripcion = ?;";
            $sql=$conectar->prepare($sql);
            $sql->bindValue(1, $terminales);
            $sql->bindValue(2, $descripcion);
            $sql->execute();
            return $resultado=$sql->fetchAll();
    }   
/* 
    Obtenemos el terminal seleccionado por el {ID}
*/
    public function get_terminales_x_id($idterminal){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="SELECT terminales.idterminal,
        terminales.terminal,
          terminales.fk_sensor,
       sensores.numero_serie
		  FROM terminales
       INNER JOIN sensores ON terminales.fk_sensor = sensores.idSensor
       WHERE idterminal = ?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $idterminal);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    } 
/* 
    Actualizar terminal por {ID}
*/
    public function update_terminales($idterminal,$fk_sensor,$terminal){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="UPDATE terminales set
            fk_sensor = ?,
            terminal = ?
            WHERE
            idterminal = ?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $fk_sensor);
        $sql->bindValue(2, $terminal);
        $sql->bindValue(3, $idterminal);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
/* 
    Eliminar terminal por {ID}
*/
    public function delete_terminal($idterminal){
        $conectar= parent::conexion();
        parent::set_names();
        $sql="UPDATE terminales set
        estado = 2
        WHERE
        idterminal = ?";
        $sql=$conectar->prepare($sql);
        $sql->bindValue(1, $idterminal);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
  
}

?>