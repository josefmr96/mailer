
<?php
/*
    Modelo de la clase reserva
*/
class Reserva extends Conectar
{
/*
    Obtenemos todas las reserva Segun el usuario que lo creo
    $fk_usuario = usuario creador de la reserva 
*/
    public function obtener_reserva($fk_idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * FROM reservas 
        LEFT JOIN  fullday ON reservas.fk_idfullday = fullday.idfullday
         WHERE fk_idfullday = ?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_idfullday);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }   
     public function obtener_pasajeros($viaje)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * FROM pasajeros 
         WHERE viaje = ?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $viaje);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }    
    public function obtener_reserva_todo($fk_idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT 
        reservas.idreserva,
        reservas.cupon,
        reservas.nombre,
        reservas.apellido,
        reservas.dni,
        reservas.fecha_nac,
        reservas.nacionalidad,
        reservas.observaciones,
        reservas.fk_usuario,
        reservas.fk_idfullday,
        reservas.fk_terminal,
        terminales.terminal
         FROM reservas 
        INNER JOIN  terminales ON reservas.fk_terminal = terminales.idterminal
        where  reservas.fk_idfullday=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_idfullday);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }  
    public function obtener_pagos($fk_reserva)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * FROM pagos WHERE fk_reserva=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_reserva);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }
/*
    Crear reserva segun datos recibidos y asignarla a un usuario 
*/
    public function insert_reserva(
    
        $cupon,
        $precio,
        $total,
        $cantidad,
        $fk_idfullday,
        $correo,
        $telefono,
        $habitacion)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO reservas (
            idreserva,
            cupon,
            precio,
            total,
            cantidad,
            fk_idfullday,
            correo,
            telefono,
            habitacion
            ) VALUES (NULL,?,?,?,?,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $cupon);
        $sql->bindValue(2, $precio);
        $sql->bindValue(3, $total);
        $sql->bindValue(4, $cantidad);
        $sql->bindValue(5, $fk_idfullday);
        $sql->bindValue(6, $correo);
        $sql->bindValue(7, $telefono);
        $sql->bindValue(8, $habitacion);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }   
     public function insert_pagos(
    
        $fk_reserva,
        $fk_usuario,
        $fk_viaje,
        $observaciones,
        $cantidad,
        $metodo,
        $numero_comprobante)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO pagos (
            idpago,
            fk_reserva,
            fk_usuario,
            fk_viaje,
            observaciones,
            cantidad,
            metodo,
            numero_comprobante
            ) VALUES (NULL,?,?,?,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $fk_reserva);
        $sql->bindValue(2, $fk_usuario);
        $sql->bindValue(3, $fk_viaje);
        $sql->bindValue(4, $observaciones);
        $sql->bindValue(5, $cantidad);
        $sql->bindValue(6, $metodo);
        $sql->bindValue(7, $numero_comprobante);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/* 
    Obtener el {ID} de la reserva segun la desccripcion y la reserva
*/
    public function get_id_reserva_insert($reserva, $dni)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT idreserva FROM reserva WHERE reserva = ? AND  dni = ?;";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $reserva);
        $sql->bindValue(2, $dni);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/*
    Obtener reserva seleccionada por {ID}
*/
public function get_reserva_x_id($idreserva)
{
    $conectar = parent::conexion();
    parent::set_names();
    $sql = "SELECT 
    reservas.idreserva,
    reservas.cupon,
    reservas.nombre,
    reservas.apellido,
    reservas.dni,
    reservas.fecha_nac,
    reservas.nacionalidad,
    reservas.observaciones,
    reservas.fk_usuario,
    reservas.fk_idfullday,
    reservas.fk_terminal,
    terminales.terminal
     FROM reservas 
    INNER JOIN  terminales ON reservas.fk_terminal = terminales.idterminal
    where reservas.idreserva=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $idreserva);
            $sql->execute();
            return $resultado = $sql->fetchAll();
}
/*
    Actualizar reserva seleccionada por {ID}
*/
    public function update_reserva($nombre, $apellido,$fecha_nac,$nacionalidad,$dni,$observaciones,$fk_terminal,$idreserva)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE reservas set
            nombre=?,
            apellido=?,
            fecha_nac=?,
            nacionalidad=?,
            dni=?,
            observaciones=?,
            fk_terminal=?
            WHERE
            idreserva = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombre);
        $sql->bindValue(2, $apellido);
        $sql->bindValue(3, $fecha_nac);
        $sql->bindValue(4, $nacionalidad);
        $sql->bindValue(5, $dni);
        $sql->bindValue(6, $observaciones);
        $sql->bindValue(7, $fk_terminal);
        $sql->bindValue(8, $idreserva);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
/* 
    Eliminar reserva selecciona por {ID}
*/
    public function delete_reserva($idreserva)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "DELETE FROM reservas
        where idreserva=?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $idreserva);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
}

?>