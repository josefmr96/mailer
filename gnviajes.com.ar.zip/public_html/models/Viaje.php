
<?php
/*
    Modelo de la clase fullday
*/
class Fullday extends Conectar
{
/*
    Obtenemos todas las fullday Segun el usuario que lo creo
    $fk_usuario = usuario creador de la fullday 
*/
    public function obtener_fullday()
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * FROM fullday";
            $sql = $conectar->prepare($sql);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }
/*
    Crear fullday segun datos recibidos y asignarla a un usuario 
*/
    public function insert_fullday($titulo, $precio,$fecha,$disponible,$descripcion,$slug,$imagen,$excursiones,$idTitulo,$oferta)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO fullday (
            idfullday,
            titulo,
            precio,
            fecha,
            disponible,
            descripcion,
            slug,
            imagen,
            excursiones,
            idTitulo,
            oferta
            ) VALUES (NULL,?,?,?,?,?,?,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $titulo);
        $sql->bindValue(2, $precio);
        $sql->bindValue(3, $fecha);
        $sql->bindValue(4, $disponible);
        $sql->bindValue(5, $descripcion);
        $sql->bindValue(6, $slug);
        $sql->bindValue(7, $imagen);
        $sql->bindValue(8, $excursiones);
        $sql->bindValue(9, $idTitulo);
        $sql->bindValue(10, $oferta);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/* 
    Obtener el {ID} de la fullday segun la desccripcion y la fullday
*/
    public function get_id_fullday_insert($fullday, $descripcion)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT idfullday FROM fullday WHERE fullday = ? AND  descripcion = ?;";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $fullday);
        $sql->bindValue(2, $descripcion);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/*
    Obtener fullday seleccionada por {ID}
*/
    public function get_fullday_x_id($idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT *
        FROM fullday
       
        where idfullday=?";
                $sql = $conectar->prepare($sql);
                $sql->bindValue(1, $idfullday);
                $sql->execute();
                return $resultado = $sql->fetchAll();
    }  
     public function get_fullday_x_slug($slug)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT *
        FROM fullday
       
        where slug=?";
                $sql = $conectar->prepare($sql);
                $sql->bindValue(1, $slug);
                $sql->execute();
                return $resultado = $sql->fetchAll();
    }       
    public function get_fullday_x_slug_y_titulo($slug,$titulo)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT *
        FROM fullday
       
        where slug=?
        and idTitulo =?";
                $sql = $conectar->prepare($sql);
                $sql->bindValue(1, $slug);
                $sql->bindValue(2, $titulo);
                $sql->execute();
                return $resultado = $sql->fetchAll();
    }
/*
    Actualizar fullday seleccionada por {ID}
*/
    public function update_fullday($titulo, $precio,$fecha,$disponible,$descripcion,$slug,$imagen,$idfullday,$excursiones,$idTitulo,$oferta)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE fullday set
            titulo=?,
            precio=?,
            fecha=?,
            disponible=?,
            descripcion=?,
            slug=?,
            imagen=?,
            excursiones=?,
            idTitulo=?,
            oferta=?
            WHERE
            idfullday = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $titulo);
        $sql->bindValue(2, $precio);
        $sql->bindValue(3, $fecha);
        $sql->bindValue(4, $disponible);
        $sql->bindValue(5, $descripcion);
        $sql->bindValue(6, $slug);
        $sql->bindValue(7, $imagen);
        $sql->bindValue(8, $excursiones);
        $sql->bindValue(9, $idTitulo);
        $sql->bindValue(10, $oferta);
        $sql->bindValue(11, $idfullday);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
    public function update_fullday_reserva($disponible,$idfullday)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE fullday set    
            disponible=?
            WHERE
            idfullday = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $disponible);
        $sql->bindValue(2, $idfullday);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
/* 
    Eliminar fullday selecciona por {ID}
*/
    public function delete_fullday($idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "DELETE FROM fullday
        where idfullday=?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $idfullday);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
}

?>