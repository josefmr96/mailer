
<?php
/*
    Modelo de la clase Pasajero
*/
class Pasajero extends Conectar
{
/*
    Obtenemos todas las Pasajero Segun el usuario que lo creo
    $fk_usuario = usuario creador de la Pasajero 
*/
    public function obtener_Pasajero($fk_usuario,$fk_idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT 
        Pasajeros.idPasajero,
        Pasajeros.cupon,
        Pasajeros.nombre,
        Pasajeros.apellido,
        Pasajeros.dni,
        Pasajeros.fecha_nac,
        Pasajeros.nacionalidad,
        Pasajeros.observaciones,
        Pasajeros.fk_usuario,
        Pasajeros.fk_idfullday,
        Pasajeros.fk_terminal,
        terminales.terminal
         FROM Pasajeros 
        INNER JOIN  terminales ON Pasajeros.fk_terminal = terminales.idterminal
        where Pasajeros.fk_usuario=? AND Pasajeros.fk_idfullday=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_usuario);
            $sql->bindValue(2, $fk_idfullday);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }    
    public function obtener_Pasajero_todo($fk_idfullday)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT 
        Pasajeros.idPasajero,
        Pasajeros.cupon,
        Pasajeros.nombre,
        Pasajeros.apellido,
        Pasajeros.dni,
        Pasajeros.fecha_nac,
        Pasajeros.nacionalidad,
        Pasajeros.observaciones,
        Pasajeros.fk_usuario,
        Pasajeros.fk_idfullday,
        Pasajeros.fk_terminal,
        terminales.terminal
         FROM Pasajeros 
        INNER JOIN  terminales ON Pasajeros.fk_terminal = terminales.idterminal
        where  Pasajeros.fk_idfullday=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_idfullday);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }  
    public function obtener_pagos($fk_Pasajero)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * FROM pagos WHERE fk_Pasajero=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $fk_Pasajero);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }
/*
    Crear Pasajero segun datos recibidos y asignarla a un usuario 
*/
    public function insert_Pasajero(
    
        $nombre,
        $comida,
        $apellido,
        $edad,
        $fecha_nac,
        $dni,
        $nacionalidad,
        $observacion,
        $terminal,
        $cupon,
        $viaje
        )
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO pasajeros (
            idpasajero,
            nombre,
            comida,
            apellido,
            edad,
            fecha_nac,
            dni,
            nacionalidad,
            observacion,
            terminal,
            cupon,
            viaje
            ) VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombre);
        $sql->bindValue(2, $comida);
        $sql->bindValue(3, $apellido);
        $sql->bindValue(4, $edad);
        $sql->bindValue(5, $fecha_nac);
        $sql->bindValue(6, $dni);
        $sql->bindValue(7, $nacionalidad);
        $sql->bindValue(8, $observacion);
        $sql->bindValue(9, $terminal);
        $sql->bindValue(10, $cupon);
        $sql->bindValue(11, $viaje);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }   
     public function insert_pagos(
    
        $fk_Pasajero,
        $fk_usuario,
        $fk_viaje,
        $observaciones,
        $cantidad,
        $metodo,
        $numero_comprobante)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO pagos (
            idpago,
            fk_Pasajero,
            fk_usuario,
            fk_viaje,
            observaciones,
            cantidad,
            metodo,
            numero_comprobante
            ) VALUES (NULL,?,?,?,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $fk_Pasajero);
        $sql->bindValue(2, $fk_usuario);
        $sql->bindValue(3, $fk_viaje);
        $sql->bindValue(4, $observaciones);
        $sql->bindValue(5, $cantidad);
        $sql->bindValue(6, $metodo);
        $sql->bindValue(7, $numero_comprobante);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/* 
    Obtener el {ID} de la Pasajero segun la desccripcion y la Pasajero
*/
    public function get_id_Pasajero_insert($Pasajero, $dni)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT idPasajero FROM Pasajero WHERE Pasajero = ? AND  dni = ?;";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $Pasajero);
        $sql->bindValue(2, $dni);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/*
    Obtener Pasajero seleccionada por {ID}
*/
public function get_Pasajero_x_id($idPasajero)
{
    $conectar = parent::conexion();
    parent::set_names();
    $sql = "SELECT 
    Pasajeros.idPasajero,
    Pasajeros.cupon,
    Pasajeros.nombre,
    Pasajeros.apellido,
    Pasajeros.dni,
    Pasajeros.fecha_nac,
    Pasajeros.nacionalidad,
    Pasajeros.observaciones,
    Pasajeros.fk_usuario,
    Pasajeros.fk_idfullday,
    Pasajeros.fk_terminal,
    terminales.terminal
     FROM Pasajeros 
    INNER JOIN  terminales ON Pasajeros.fk_terminal = terminales.idterminal
    where Pasajeros.idPasajero=?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $idPasajero);
            $sql->execute();
            return $resultado = $sql->fetchAll();
}
/*
    Actualizar Pasajero seleccionada por {ID}
*/
    public function update_Pasajero($nombre, $apellido,$fecha_nac,$nacionalidad,$dni,$observaciones,$fk_terminal,$idPasajero)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE Pasajeros set
            nombre=?,
            apellido=?,
            fecha_nac=?,
            nacionalidad=?,
            dni=?,
            observaciones=?,
            fk_terminal=?
            WHERE
            idPasajero = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombre);
        $sql->bindValue(2, $apellido);
        $sql->bindValue(3, $fecha_nac);
        $sql->bindValue(4, $nacionalidad);
        $sql->bindValue(5, $dni);
        $sql->bindValue(6, $observaciones);
        $sql->bindValue(7, $fk_terminal);
        $sql->bindValue(8, $idPasajero);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
/* 
    Eliminar Pasajero selecciona por {ID}
*/
    public function delete_Pasajero($idPasajero)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "DELETE FROM Pasajeros
        where idPasajero=?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $idPasajero);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
}

?>