<?php
/*
    Modelo de la clase Banner
*/
class Banner extends Conectar
{
/*
    Obtenemos todas las Banner Segun el usuario que lo creo
    $fk_usuario = usuario creador de la Banner 
*/
    public function obtener_Banner()
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT * from banners
        WHERE slug NOT IN ('PromoEspecial');
        ";
            $sql = $conectar->prepare($sql);
            $sql->execute();
            return $resultado = $sql->fetchAll();
    }
/*
    Crear Banner segun datos recibidos y asignarla a un usuario 
*/
    public function insert_Banner($titulo, $slug,$url,$estado)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "INSERT INTO banners (
            idpromo,
            titulo,
            slug,
            url,
            estado
            ) VALUES (NULL,?,?,?,?);";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $titulo);
        $sql->bindValue(2, $slug);
        $sql->bindValue(3, $url);
        $sql->bindValue(4, $estado);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/* 
    Obtener el {ID} de la Banner segun la desccripcion y la Banner
*/
    public function get_id_Banner_insert($Banner, $descripcion)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT idBanner FROM Banner WHERE Banner = ? AND  descripcion = ?;";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $Banner);
        $sql->bindValue(2, $descripcion);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
/*
    Obtener Banner seleccionada por {ID}
*/
    public function get_Banner_x_id($idBanner)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT *
        FROM Banner
       
        where idBanner=?";
                $sql = $conectar->prepare($sql);
                $sql->bindValue(1, $idBanner);
                $sql->execute();
                return $resultado = $sql->fetchAll();
    }  
      public function get_Banner_x_slut($slut)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "SELECT *
        FROM banners
       
        where slug=?";
                $sql = $conectar->prepare($sql);
                $sql->bindValue(1, $slut);
                $sql->execute();
                return $resultado = $sql->fetchAll();
    }
/*
    Actualizar Banner seleccionada por {ID}
*/
    public function update_Banner($titulo, $precio,$fecha,$disponible,$descripcion,$slug,$imagen,$idBanner)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE Banner set
            titulo=?,
            precio=?,
            fecha=?,
            disponible=?,
            descripcion=?,
            slug=?,
            imagen=?
            WHERE
            idBanner = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $titulo);
        $sql->bindValue(2, $precio);
        $sql->bindValue(3, $fecha);
        $sql->bindValue(4, $disponible);
        $sql->bindValue(5, $descripcion);
        $sql->bindValue(6, $slug);
        $sql->bindValue(7, $imagen);
        $sql->bindValue(8, $idBanner);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
    public function update_Banner_reserva($disponible,$idBanner)
    {
        $conectar= parent::conexion();
        parent::set_names();
        $sql = "UPDATE Banner set    
            disponible=?
            WHERE
            idBanner = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $disponible);
        $sql->bindValue(2, $idBanner);
        $sql->execute();
        return $resultado=$sql->fetchAll();
    }
/* 
    Eliminar Banner selecciona por {ID}
*/
    public function delete_Banner($idpromo)
    {
        $conectar = parent::conexion();
        parent::set_names();
        $sql = "DELETE FROM banners
        where idpromo=?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $idpromo);
        $sql->execute();
        return $resultado = $sql->fetchAll();
    }
}

?>